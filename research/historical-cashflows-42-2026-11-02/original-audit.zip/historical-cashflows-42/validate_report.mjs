// Offline structure/behavior simulation. This is not a browser or visual preview.
import fs from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const dir=new URL('.',import.meta.url).pathname;
const html=await fs.readFile(dir+'report.html','utf8');
const blob=html.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const program=html.match(/<\/script><script>([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(blob),nodes=new Map(),listeners={};
function node(selector){if(!nodes.has(selector))nodes.set(selector,{value:'',checked:false,hidden:false,innerHTML:'',textContent:'',attributes:{},classes:new Set(),setAttribute(k,v){this.attributes[k]=v;},classList:{toggle(k,v){const n=nodes.get(selector);if(v)n.classes.add(k);else n.classes.delete(k);}}});return nodes.get(selector);}
const document={querySelector:node,getElementById:id=>id==='data'?{textContent:blob}:node('#'+id),addEventListener:(name,f)=>listeners[name]=f};
const context=vm.createContext({document});vm.runInContext(program,context,{timeout:10000});
const run=s=>vm.runInContext(s,context,{timeout:10000});
const checks=[];
assert.equal((node('#company').innerHTML.match(/<option /g)||[]).length,42);checks.push('42 issuer options');
assert.equal((node('#results-table').innerHTML.match(/<tbody>[\s\S]*?<\/tbody>/)[0].match(/<tr>/g)||[]).length,5);checks.push('five initial AAPL rows');
assert.equal(run('fmt("0")'),'0.00B');assert.equal(run('fmt(null)'),'Unavailable');checks.push('zero is distinct from unavailable');
node('#expanded').checked=true;run('render()');assert.match(node('#results-table').innerHTML,/Expanded FCFF/);assert.match(node('#results-table').innerHTML,/Expanded FCFE/);checks.push('expanded investment columns');
node('#search').value='Apple';run('render()');assert.equal((node('#company').innerHTML.match(/<option /g)||[]).length,1);assert.match(node('#selected-name').textContent,/AAPL/);checks.push('company-name search');
node('#search').value='definitely-no-such-issuer-9382';run('render()');assert.equal(node('#selected-name').textContent,'No matching issuer');checks.push('empty search state');
node('#search').value='';run('render();showView("coverage")');assert.equal((node('#coverage-table').innerHTML.match(/<tbody>[\s\S]*?<\/tbody>/)[0].match(/<tr>/g)||[]).length,42);assert.equal(node('#coverage-tab').attributes['aria-selected'],true);checks.push('42-row coverage and tab state');
for(const ticker of data.metadata.universe){run(`selected=${JSON.stringify(ticker)};selectedPeriod=null;render()`);assert.equal((node('#results-table').innerHTML.match(/<tbody>[\s\S]*?<\/tbody>/)[0].match(/<tr>/g)||[]).length,5);}
checks.push('five requested slots for every issuer');
for(const r of data.results){run(`showPeriod(${JSON.stringify(r.period_key)})`);assert.equal(node('#period-detail').hidden,false);assert.match(node('#period-detail').innerHTML,/Calculation inputs and filing cells/);assert.match(node('#period-detail').innerHTML,/Financing cash schedule/);if(data.flags.some(f=>f.period_key===r.period_key))assert.match(node('#period-detail').innerHTML,/Next step:/);}
checks.push('210 fiscal-period/missing-slot detail views with remedies');
run('selected="XOM";selectedPeriod=null;render()');assert.equal((node('#results-table').innerHTML.match(/Not assigned/g)||[]).length,5);checks.push('missing history has no invented dates');
assert.equal(run('e("<img src=x>")'),'&lt;img src=x&gt;');checks.push('source text escaping');
assert(!html.includes('134 supported'));assert(html.includes('connect-src \'none\''));checks.push('current coverage and offline CSP');
await fs.writeFile(dir+'report-validation.json',JSON.stringify({scope:'Offline HTML and JavaScript structure/behavior simulation; no browser rendering or network access.',checks,errors:[],period_details_checked:data.results.length},null,2));
console.log('Passed',checks.length,'report checks');
