import fs from 'node:fs/promises';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';
const dir=new URL('.',import.meta.url).pathname;
const data=JSON.parse(await fs.readFile(dir+'review-data.json','utf8'));
const wb=Workbook.create();
const names=['Summary','Cashflows','Financing','Flags','Sources','Checks','Methodology'];
const sheets=Object.fromEntries(names.map(n=>[n,wb.worksheets.add(n)]));
const navy='#183E50',muted='#61748A',gold='#AB8732',blue='#2157AE',green='#17744C',red='#A52E34',pale='#F1F5F7';
const money='#,##0.00;(#,##0.00);"—"';
const number=v=>v===null||v===undefined||v===''?null:Number(v)/1e6;
const serial=s=>s?Date.parse(s+'T00:00:00Z')/86400000+25569:null;
const col=i=>{let s='';for(i++;i;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;};
function layout(name,title,subtitle,headers,rows,widths){
 const sh=sheets[name],last=col(headers.length-1),titleEnd=col(Math.min(headers.length-1,7)),end=6+rows.length;
 sh.showGridLines=false;sh.tabColor=['Summary','Cashflows'].includes(name)?navy:muted;
 sh.getRange(`A1:${last}${end}`).format.font={name:'Arial',size:10,color:navy};
 sh.getRange(`A1:${last}${end}`).format.rowHeight=25;
 sh.getRange(`A1:${titleEnd}1`).merge();sh.getRange('A1').values=[[title]];sh.getRange('A1').format.font={name:'Arial',size:22,bold:true,color:navy};sh.getRange('A1').format.rowHeight=38;
 sh.getRange(`A2:${titleEnd}3`).merge();sh.getRange('A2').values=[[subtitle]];sh.getRange(`A2:${titleEnd}3`).format={wrapText:true,font:{name:'Arial',size:10,color:muted},verticalAlignment:'center'};
 sh.getRange(`A6:${last}6`).values=[headers];
 if(rows.length)sh.getRange(`A7:${last}${end}`).values=rows;
 const table=sh.tables.add(`A6:${last}${end}`,true,name+'Review');table.style='TableStyleLight1';
 sh.getRange(`A7:${last}${end}`).format.verticalAlignment='center';
 sh.getRange(`A6:${last}6`).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:36,verticalAlignment:'center'};
 widths.forEach((w,i)=>{sh.getRange(`${col(i)}:${col(i)}`).format.columnWidth=w;});
 sh.freezePanes.freezeRows(6);sh.freezePanes.freezeColumns(name==='Cashflows'?2:1);
 return sh;
}
const sourceRows=data.sources.map(s=>[s.period_key,s.ticker,s.fiscal_year,serial(s.annual_end),s.field,number(s.value_usd),s.concept,s.caption,s.primary_url,s.primary_sha256,s.table,s.row,s.cell,s.context,s.instance_url,s.instance_sha256,s.instance_ordinals,s.evidence,s.field.startsWith('investment adjustment / ')?'INVESTMENT_ADJUSTMENT':'INPUT_COMPONENT']);
layout('Sources','Filing source inputs','USD millions. Blue values are source inputs; exact USD, contexts, hashes and all alternate primary bindings are retained in calculations.json. Table/row/cell/instance ordinals are zero-based.',
 ['Period key','Issuer','Fiscal year','Fiscal end','Input / component','Reported amount','Concept','Displayed caption','Primary filing URL','Primary SHA-256','Table','Row','Cell','Annual context','Instance URL','Instance SHA-256','Instance ordinals','Evidence basis','Source role'],sourceRows,[26,10,12,14,38,19,35,55,50,25,9,9,9,35,50,25,18,32,30]);
const so=sheets.Sources;so.getRange(`F7:F${6+sourceRows.length}`).setNumberFormat(money);so.getRange(`F7:F${6+sourceRows.length}`).format.font.color=blue;so.getRange(`D7:D${6+sourceRows.length}`).setNumberFormat('dd-mmm-yyyy');so.getRange(`G7:H${6+sourceRows.length}`).format.wrapText=true;so.getRange(`A7:S${6+sourceRows.length}`).format.rowHeight=48;
const findSources=(key,field)=>data.sources.flatMap((s,i)=>s.period_key===key&&(s.field===field||s.field.startsWith(field+' / term '))?[{...s,row:i+7}]:[]);
function sourceFormula(key,field){
 const rr=findSources(key,field);if(!rr.length)return null;
 const terms=rr.map(s=>{const m=s.field.match(/\((-?\d+)\)$/);return (m?m[1]+'*':'')+`Sources!F${s.row}`;});
 return '='+terms.join('+');
}
const finRows=data.financing.map(r=>[r.period_key,r.ticker,r.fiscal_year,serial(r.annual_end),r.caption,r.classification,number(r.signed_cash_usd),r.included_in_net_borrowing?1:0,null,r.primary_url,r.primary_sha256,r.table,r.row,r.concept]);
layout('Financing','Net debt cash funding schedule','USD millions; receipts positive and payments negative. Included cash uses each selected debt/lease/cost component once. Excluded owner/Other financing cash remains visible; no debt balance changes substitute for cash flows.',
 ['Period key','Issuer','Fiscal year','Fiscal end','Displayed financing caption','Classification','Signed cash','Included (1/0)','Selected funding cash','Primary filing URL','Primary SHA-256','Table','Row','Concept'],finRows,[26,10,12,14,58,40,20,15,22,50,25,9,9,42]);
const fin=sheets.Financing,finEnd=6+finRows.length;
fin.getRange(`I7:I${finEnd}`).formulas=finRows.map((_,i)=>[`=G${i+7}*H${i+7}`]);fin.getRange(`G7:I${finEnd}`).setNumberFormat(money);fin.getRange(`G7:H${finEnd}`).format.font.color=blue;fin.getRange(`I7:I${finEnd}`).format.font.color='#000000';fin.getRange(`H7:H${finEnd}`).setNumberFormat('0');fin.getRange(`D7:D${finEnd}`).setNumberFormat('dd-mmm-yyyy');
fin.getRange(`E7:F${finEnd}`).format.wrapText=true;fin.getRange(`A7:N${finEnd}`).format.rowHeight=42;
const cashRows=data.results.map(r=>[r.period_key,r.ticker,r.fiscal_year,serial(r.annual_end),null,null,null,null,null,null,null,null,null,null,null,null,null,null,r.fcff_status,r.fcfe_status,r.history_origin,r.flag_count]);
layout('Cashflows','Five-year historical cash-flow calculations','USD millions. Empty cells mean unavailable, not zero. Inputs link to filing sources; net funding links to its cash schedule. Baseline and expanded-investment results are separate conventions. Status is an independent economic review, not a formula-error test.',
 ['Period key','Issuer','Fiscal year','Fiscal end','Operating cash flow','Cash capex baseline','Selected interest expense','Tax provision','Pretax income','Reported tax rate','Net debt cash funding','Reported preferred cash','Cash FCF','FCFF baseline','FCFE baseline','Expanded investment','Expanded FCFF','Expanded FCFE','FCFF review status','FCFE review status','History origin','Flags'],cashRows,[26,10,12,14,21,21,23,19,20,19,23,24,21,22,22,24,23,23,40,40,30,9]);
const cash=sheets.Cashflows,cashEnd=6+cashRows.length,sourceEnd=6+sourceRows.length;
data.results.forEach((r,i)=>{
 const n=i+7;for(const [c,f] of [[4,'cfo'],[5,'cash_capex'],[6,'interest_expense'],[7,'tax_provision'],[8,'pretax_income'],[11,'preferred_cash_dividends']]){const formula=sourceFormula(r.period_key,f);if(formula)cash.getRange(`${col(c)}${n}`).formulas=[[formula]];}
 cash.getRange(`J${n}`).formulas=[[`=IF(OR(COUNT(H${n},I${n})<>2,I${n}=0),"",H${n}/I${n})`]];
 if(r.net_borrowing_usd!==null)cash.getRange(`K${n}`).formulas=[[`=SUMIFS(Financing!$I$7:$I$${finEnd},Financing!$A$7:$A$${finEnd},A${n})`]];
 cash.getRange(`M${n}`).formulas=[[`=IF(COUNT(E${n},F${n})<>2,"",E${n}-F${n})`]];
 cash.getRange(`N${n}`).formulas=[[`=IF(COUNT(M${n},G${n},J${n})<>3,"",M${n}+G${n}*(1-J${n}))`]];
 cash.getRange(`O${n}`).formulas=[[`=IF(COUNT(M${n},K${n})<>2,"",IF(COUNT(L${n})=0,M${n}+K${n},M${n}+K${n}-L${n}))`]];
 cash.getRange(`P${n}`).formulas=[[`=IF(COUNT(F${n})=0,"",F${n}-SUMIFS(Sources!$F$7:$F$${sourceEnd},Sources!$A$7:$A$${sourceEnd},A${n},Sources!$S$7:$S$${sourceEnd},"INVESTMENT_ADJUSTMENT"))`]];
 cash.getRange(`Q${n}`).formulas=[[`=IF(COUNT(N${n},P${n})<>2,"",N${n}-(P${n}-F${n}))`]];
 cash.getRange(`R${n}`).formulas=[[`=IF(COUNT(O${n},P${n})<>2,"",O${n}-(P${n}-F${n}))`]];
});
cash.getRange(`E7:R${cashEnd}`).setNumberFormat(money);cash.getRange(`J7:J${cashEnd}`).setNumberFormat('0.00%;(0.00%);"—"');cash.getRange(`D7:D${cashEnd}`).setNumberFormat('dd-mmm-yyyy');cash.getRange(`E7:L${cashEnd}`).format.font.color=green;cash.getRange(`J7:J${cashEnd}`).format.font.color='#000000';cash.getRange(`M7:O${cashEnd}`).format.font.color='#000000';cash.getRange(`P7:P${cashEnd}`).format.font.color=green;cash.getRange(`Q7:R${cashEnd}`).format.font.color='#000000';cash.getRange(`N7:O${cashEnd}`).format.fill='#EAF1F4';
const summaryRows=data.companies.map(c=>[c.ticker,c.fiscal_years,null,null,null,null,null,null,null,c.review_codes||'No issuer-specific review code under the stated cash convention.']);
layout('Summary','Historical FCFF & FCFE | 42 companies','210 requested fiscal-year slots • 203 retained research periods • 7 missing slots. Results are calculated from reported filing inputs; provisional numbers are saved for review and must not be imported as approved platform data. Detailed amounts are in Cashflows.',
 ['Issuer','Source fiscal years','Periods in bank','FCFF supported','FCFF provisional','FCFF unavailable','FCFE supported','FCFE provisional','FCFE unavailable','Unresolved review codes'],summaryRows,[11,32,17,18,18,19,18,18,19,86]);
const sum=sheets.Summary;
data.companies.forEach((c,i)=>{const n=i+7;sum.getRange(`C${n}`).formulas=[[`=COUNTIFS(Cashflows!$B$7:$B$${cashEnd},A${n},Cashflows!$U$7:$U$${cashEnd},"<>UNAVAILABLE")`]];for(const [dest,source,status] of [['D','S','SUPPORTED_UNDER_STATED_REPORTED_CASH_CONVENTION'],['E','S','PROVISIONAL_REVIEW_REQUIRED'],['F','S','UNAVAILABLE'],['G','T','SUPPORTED_UNDER_STATED_REPORTED_CASH_CONVENTION'],['H','T','PROVISIONAL_REVIEW_REQUIRED'],['I','T','UNAVAILABLE']])sum.getRange(`${dest}${n}`).formulas=[[`=COUNTIFS(Cashflows!$B$7:$B$${cashEnd},A${n},Cashflows!$${source}$7:$${source}$${cashEnd},"${status}")`]];});
sum.getRange('J7:J48').format.wrapText=true;data.companies.forEach((c,i)=>sum.getRange(`A${i+7}:J${i+7}`).format.rowHeight=Math.max(38,14*Math.ceil((c.review_codes||'').length/100)+14));sum.getRange('D7:I48').format.horizontalAlignment='center';
const flagRows=data.flags.map(f=>[f.ticker,f.fiscal_year,serial(f.annual_end),f.severity,f.affects,f.code,f.explanation,f.remedy,f.accession,f.primary_url]);
layout('Flags','Company-year issues and remedies','Every missing or provisional result has an explicit reason. NOTE records preserve scope/rounding decisions; REVIEW and BLOCKER records require attention before acceptance. No residual amount is silently estimated.',
 ['Issuer','Fiscal year','Fiscal end','Severity','Affects','Issue code','What is unresolved / observed','How to resolve it','Accession','Primary filing URL'],flagRows,[11,12,14,14,16,40,85,85,25,55]);
sheets.Flags.getRange(`G7:H${flagRows.length+6}`).format.wrapText=true;data.flags.forEach((f,i)=>sheets.Flags.getRange(`A${i+7}:J${i+7}`).format.rowHeight=Math.max(52,14*Math.ceil(Math.max(f.explanation.length,f.remedy.length)/100)+20));sheets.Flags.getRange(`C7:C${flagRows.length+6}`).setNumberFormat('dd-mmm-yyyy');
const checkRows=data.results.map((r,i)=>[r.period_key,r.ticker,r.fiscal_year,null,number(r.fcff_usd),null,null,number(r.fcfe_usd),null,null,number(r.expanded_fcff_usd),null,null,number(r.expanded_fcfe_usd),null,ciStatus(r.period_key),ciDelta(r.period_key)]);
function ciStatus(key){return data.cash_controls.find(c=>c.ticker+'|'+c.identity.annual_end===key)?.status||'NO_RETAINED_PERIOD';}
function ciDelta(key){const c=data.cash_controls.find(c=>c.ticker+'|'+c.identity.annual_end===key);return number(c?.difference_usd);}
layout('Checks','Calculation and source controls','USD millions. Differences compare workbook formulas against independently saved exact-rational results; target absolute difference ≤0.00000001 million (USD 0.01). Missing checks remain blank. A tied cash statement does not prove economic classification completeness.',
 ['Period key','Issuer','Fiscal year','Workbook FCFF','Exact FCFF reference','FCFF difference','Workbook FCFE','Exact FCFE reference','FCFE difference','Expanded FCFF','Exact expanded FCFF','Expanded FF difference','Expanded FCFE','Exact expanded FCFE','Expanded FE difference','Whole cash statement control','Whole cash difference'],checkRows,[26,11,12,21,24,22,21,24,22,22,25,23,22,25,23,60,24]);
const check=sheets.Checks;
data.results.forEach((r,i)=>{const n=i+7;for(const [dst,src,expected,diff] of [['D','N','E','F'],['G','O','H','I'],['J','Q','K','L'],['M','R','N','O']]){
 check.getRange(`${dst}${n}`).formulas=[[`=IF(COUNT(Cashflows!${src}${n})=0,"",Cashflows!${src}${n})`]];
 check.getRange(`${diff}${n}`).formulas=[[`=IF(COUNT(${dst}${n},${expected}${n})<>2,"",${dst}${n}-${expected}${n})`]];
}});
check.getRange(`D7:Q${cashEnd}`).setNumberFormat(money);check.getRange(`E7:E${cashEnd}`).format.font.color=blue;check.getRange(`H7:H${cashEnd}`).format.font.color=blue;check.getRange(`K7:K${cashEnd}`).format.font.color=blue;check.getRange(`N7:N${cashEnd}`).format.font.color=blue;
for(const c of ['F','I','L','O','Q'])check.getRange(`${c}7:${c}${cashEnd}`).setNumberFormat('#,##0.00;(#,##0.00);"0.00"');
const methodRows=data.methodology.map(m=>[m.topic,m.explanation]);
methodRows.push(['Numerical checks',Object.entries(data.validation_checks).map(([k,v])=>k+': '+v).join('; ')]);
methodRows.push(['Reading values','Baseline means the platform’s selected cash-capex convention. Expanded results show an identified broader investment perimeter and retain the same review flags. A missing preferred-cash input does not assert there are no preferred claims; review Flags. Do not total unrelated issuers or incompatible fiscal years.']);
methodRows.push(['Reproducibility','Source inputs in Sources; face and note funding rows in Financing; formulas in Cashflows; terminal audit checks in Checks. calculations.json preserves exact fractions, alternate primary bindings and later comparative values. No canonical application inputs or approval files were changed.']);
layout('Methodology','Definitions, source choices and limits','Read before using these figures in a forecast, chart, valuation or production database.', ['Topic','Method / limitation'],methodRows,[35,140]);
sheets.Methodology.getRange(`A7:B${methodRows.length+6}`).format.wrapText=true;methodRows.forEach((r,i)=>sheets.Methodology.getRange(`A${i+7}:B${i+7}`).format.rowHeight=Math.max(38,14*Math.ceil(r[1].length/180)+16));
for(const name of ['Cashflows','Flags']){
 const sh=sheets[name],rows=name==='Cashflows'?cashRows.length:flagRows.length;
 const cols=name==='Cashflows'?['S','T']:['D'];
 for(const c of cols){const range=sh.getRange(`${c}7:${c}${rows+6}`);range.conditionalFormats.add('containsText',{text:'PROVISIONAL',format:{fill:'#FFF1D6',font:{color:'#805C18'}}});range.conditionalFormats.add('containsText',{text:'UNAVAILABLE',format:{fill:'#FBE9E8',font:{color:red,bold:true}}});range.conditionalFormats.add('containsText',{text:'BLOCKER',format:{fill:'#FBE9E8',font:{color:red,bold:true}}});range.conditionalFormats.add('containsText',{text:'REVIEW',format:{fill:'#FFF1D6',font:{color:'#805C18'}}});}
}
wb.recalculate();
const failures=[];
for(let i=0;i<data.results.length;i++){
 const r=data.results[i],n=i+7;
 for(const [c,field] of [['N','fcff_usd'],['O','fcfe_usd'],['Q','expanded_fcff_usd'],['R','expanded_fcfe_usd']]){
  const actual=cash.getRange(`${c}${n}`).values[0][0],expected=number(r[field]);
  if(expected===null){if(actual!==null&&actual!=='')failures.push({key:r.period_key,c,actual,expected});}
  else if(typeof actual!=='number'||Math.abs(actual-expected)>1e-8)failures.push({key:r.period_key,c,actual,expected});
 }
}
// A real dependency test: change a source CFO amount, require both measures to move, then restore.
const testRow=data.sources.findIndex(s=>s.period_key==='AAPL|2021-09-25'&&s.field==='cfo')+7;
const cashRow=data.results.findIndex(s=>s.period_key==='AAPL|2021-09-25')+7;
const original=so.getRange(`F${testRow}`).values[0][0];const before=cash.getRange(`N${cashRow}:O${cashRow}`).values[0];
so.getRange(`F${testRow}`).values=[[original+100]];wb.recalculate();const perturbed=cash.getRange(`N${cashRow}:O${cashRow}`).values[0];
if(perturbed.some((v,i)=>Math.abs(v-before[i]-100)>1e-8))failures.push({dependencyTest:{before,perturbed}});
so.getRange(`F${testRow}`).values=[[original]];wb.recalculate();
for(const name of names){const values=sheets[name].getUsedRange().values;for(let r=0;r<values.length;r++)for(let c=0;c<(values[r]?.length||0);c++){const v=values[r][c];if(typeof v==='string'&&/^#(REF!|VALUE!|DIV\/0!|NAME\?|N\/A|NUM!|SPILL!|CALC!)/.test(v))failures.push({sheet:name,r:r+1,c:c+1,v});}}
await fs.writeFile(dir+'workbook-validation.json',JSON.stringify({failures,formulaResultsChecked:data.results.length*4,sourcePerturbation:{period:'AAPL FY2021',amount_change_usdm:100,before,perturbed,restored:true}},null,2));
console.log('Validation failures',failures.length);if(failures.length)throw new Error(JSON.stringify(failures.slice(0,12)));
await fs.writeFile(dir+'workbook-inspection.txt',JSON.stringify(await wb.inspect({kind:'table',range:'Cashflows!A6:O11',include:'values,formulas',maxChars:7000}),null,2));
await fs.mkdir(dir+'previews',{recursive:true});
for(const [name,range] of [['Summary','A1:I15'],['Cashflows','A1:O12'],['Financing','A1:I14'],['Flags','A1:H11'],['Sources','A1:H12'],['Checks','A1:I12'],['Methodology','A1:B12']]){
 const p=await wb.render({sheetName:name,range,scale:1,format:'png'});await fs.writeFile(dir+'previews/'+name+'.png',new Uint8Array(await p.arrayBuffer()));console.log('Rendered',name);
}
const file=await SpreadsheetFile.exportXlsx(wb);await file.save(dir+'historical-cashflows.xlsx');console.log('Saved historical-cashflows.xlsx');
