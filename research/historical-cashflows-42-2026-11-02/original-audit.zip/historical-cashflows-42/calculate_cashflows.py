"""Source-bound research calculations. No application/approval state is changed.

Baseline preserves the platform's reported cash-capex convention. Additional
investment is quantified separately; mixed/noncommon/lease scopes are flagged.
"""
from pathlib import Path
from collections import defaultdict,Counter
from decimal import Decimal,localcontext
from fractions import Fraction
import csv,hashlib,json,re
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/kc/Projects/valuation-platform')
E=json.loads((OUT/'evidence-final.json').read_text())
COMP=json.loads((OUT/'interest-comparatives.json').read_text())
SUPP=json.loads((OUT/'supplemental-operands.json').read_text())
VINTAGES=json.loads((OUT/'comparative-checks-bound.json').read_text()) if (OUT/'comparative-checks-bound.json').exists() else {'differences':[]}
RULE_VERSION='retained-cashflow-research-2026-11-02-v2'

CAPEX={
 'AMZN':['PaymentsToAcquireProductiveAssets'],'CVX':['PaymentsToAcquireProductiveAssets'],
 'GEV':['PaymentsToAcquireProductiveAssets'],'HD':['PaymentsToAcquireProductiveAssets'],
 'LLY':['PaymentsToAcquireOtherPropertyPlantAndEquipment'],
 'LRCX':['PaymentsToAcquireProductiveAssets'],
 'MRK':['PaymentsToAcquirePropertyPlantAndEquipment','PaymentsToAcquireProductiveAssets'],
 'NVDA':['PaymentsToAcquireProductiveAssets','PurchasesOfPropertyAndEquipmentAndIntangibleAssets'],
 'PEP':['PaymentsToAcquireProductiveAssets'],'QCOM':['PaymentsToAcquireProductiveAssets'],
 'V':['PaymentsToAcquireProductiveAssets'],'VZ':['PaymentsToAcquireOtherProductiveAssets'],
}
INTEREST=['InterestExpense','InterestExpenseNonoperating','InterestAndDebtExpense']
PRETAX=['IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest','IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments','IncomeLossFromContinuingOperationsBeforeIncomeTaxes','IncomeLossFromContinuingOperationsIncludingNoncontrollingInterestBeforeIncomeTaxesExtraordinaryItems','IncomeLossFromContinuingOperationsAfterNoncontrollingInterestBeforeIncomeTaxes']

def dec(v):
 if v is None:return None
 if not isinstance(v,Fraction):v=Fraction(v)
 with localcontext() as c:
  c.prec=50;return str(Decimal(v.numerator)/Decimal(v.denominator))
def exact(v):return None if v is None else dict(numerator=str(v.numerator),denominator=str(v.denominator),decimal_usd=dec(v))
def primaries(p,con=None,dims=False):
 for d in p['primary']:
  for t in d['tables']:
   for r in t['rows']:
    for f in r['facts']:
     if not dims and f['dimensions']:continue
     if con is not None and f['concept'].split(':')[-1]!=con:continue
     yield dict(source=d['source'],context_source=d.get('context_source'),table=t['table'],row=r['row'],caption=r['caption'],text=r['text'],**f)
def candidate(p,concept,mode='raw',caption=None):
 raw=[f for f in p['instance']['facts'] if f['concept']==concept and not f['dimensions']]
 if not raw:return None
 def precision(f):return 999 if str(f['precision']).upper()=='INF' else int(f['precision'])
 finest=max(precision(f) for f in raw)
 selected=[f for f in raw if precision(f)==finest]
 vals={Fraction(f['value_usd']) for f in selected}
 if len(vals)!=1:return None
 value=next(iter(vals))
 def halfunit(f):return Fraction(0) if precision(f)==999 else Fraction(10)**(-precision(f))/2
 if any(abs(Fraction(f['value_usd'])-value)>halfunit(f)+halfunit(selected[0]) for f in raw):return None
 rounded=[f for f in raw if f not in selected]
 raw=selected
 display=[f for f in primaries(p,concept) if abs(Fraction(f['displayed_value_usd']))==abs(value) and (caption is None or caption(f['caption']))]
 if not display:return None
 # A magnitude is allowed only for an explicitly named expense/payment role.
 if mode=='magnitude':value=abs(value)
 if mode=='cash':
  signs={Fraction(f['displayed_value_usd']) for f in display}
  if len(signs)!=1:return None
  value=next(iter(signs))
 return dict(value_usd=dec(value),unit='USD',concept=concept,role=mode,
  target_period={k:p['identity'][k] for k in ('cik','annual_start','annual_end')},source_filing_identity=p.get('source_filing_identity',p['identity']),
  instance=dict(source=p['instance']['source'],observations=raw,compatible_rounded_observations=rounded),primary=display,
  evidence_depth='EXACT_ANNUAL_USD_INSTANCE_AND_PRIMARY_CASH_OR_EXPENSE_CAPTION')
def choose(p,concepts,**kw):
 for c in concepts:
  value=candidate(p,c,**kw)
  if value:return value
 return None
def derived(name,terms,explanation):
 if any(p is None for sign,p in terms):return None
 v=sum((Fraction(sign)*Fraction(p['value_usd']) for sign,p in terms),Fraction(0))
 return dict(value_usd=dec(v),unit='USD',concept=name,derivation=explanation,terms=[dict(multiplier=sign,point=p) for sign,p in terms],evidence_depth='DERIVED_FROM_EXACT_BOUND_REPORTED_COMPONENTS')

def dimensioned_point(p,concept,member):
 raw=[f for f in p['instance']['facts'] if f['concept']==concept and len(f['dimensions'])==1 and f['dimensions'][0].get('member','').split(':')[-1]==member]
 values={Fraction(f['value_usd']) for f in raw}
 if len(values)!=1:return None
 value=next(iter(values));display=[f for f in primaries(p,concept,dims=True) if len(f['dimensions'])==1 and f['dimensions'][0][1].split(':')[-1]==member and abs(Fraction(f['displayed_value_usd']))==abs(value)]
 if not display:return None
 return dict(value_usd=dec(value),unit='USD',concept=concept,role='Exact explicitly named non-overlapping business perimeter',target_period={k:p['identity'][k] for k in ('cik','annual_start','annual_end')},source_filing_identity=p['source_filing_identity'],instance=dict(source=p['instance']['source'],observations=raw),primary=display,evidence_depth='EXACT_ANNUAL_DIMENSIONED_USD_INSTANCE_AND_PRIMARY')

def issue(code,severity,affects,explanation,fix,**extra):
 return dict(code=code,severity=severity,affects=affects,explanation=explanation,remedy=fix,**extra)

def interest(p):
 t=p['ticker'];flags=[]
 # Never substitute net interest, cash interest, tax interest or total incurred costs.
 gross_caption=lambda c:bool(re.search(r'interest (?:expense|and debt expense)|interest expense on borrowings',c,re.I)) and not re.search(r'\bnet\b(?! of (?:portion )?capitaliz)',c,re.I)
 point=choose(p,INTEREST,mode='magnitude',caption=gross_caption)
 if t=='LIN':
  netcons=['InterestAndDebtExpense','InterestIncomeExpenseNet','InterestExpenseNonoperating']
  net=choose(p,netcons,mode='magnitude',caption=lambda c:bool(re.search(r'^\$?$|interest expense.*net',c,re.I)))
  inc=choose(p,['InterestIncomeOther'],mode='magnitude',caption=lambda c:'interest income' in c.lower())
  point=derived('GROSS_EXPENSE_FROM_NET_AND_SEPARATE_INCOME',[(1,net),(1,inc)],'Gross expensed interest = displayed net interest expense + separately disclosed interest income; debt incurred/capitalized/amortization table is preserved for cross-check.')
  incurred=choose(p,['InterestExpenseDebt'],mode='cash',caption=lambda c:'incurred on debt' in c.lower())
  amort=choose(p,['AmortizationOnAssumedDebt'],mode='cash',caption=lambda c:'amortization on acquired debt' in c.lower())
  capitalized=choose(p,['InterestCostsCapitalizedAdjustment'],mode='cash',caption=lambda c:'interest capitalized' in c.lower())
  independent=derived('INTEREST_INCURRED_PLUS_SIGNED_AMORTIZATION_LESS_CAPITALIZED',[(1,incurred),(1,amort),(1,capitalized)],'Independent debt-note build: interest incurred plus signed acquired-debt amortization and signed capitalized interest. Interest income is excluded from this gross expense build.')
  if point and independent:
   point['independent_reconstruction']=independent
   delta=Fraction(point['value_usd'])-Fraction(independent['value_usd'])
   flags.append(issue('INTEREST_NOTE_RECONCILIATION','NOTE' if delta==0 else 'REVIEW',['FCFF'],f"Net interest plus separately disclosed interest income versus the independent debt-note reconstruction differs by {dec(delta)} USD.",'Preserve both exact source builds and the distinction between interest incurred, capitalized interest, acquired-debt amortization and interest income.'))
  if amort and Fraction(amort['value_usd']):flags.append(issue('NONCASH_ACQUIRED_DEBT_AMORTIZATION_IN_INTEREST','REVIEW',['FCFF'],f"Selected expensed interest includes a separately disclosed acquired-debt amortization amount of {amort['value_usd']} USD. It is not the same as cash borrowing interest.",'Reconcile this noncash credit/cost to CFO adjustments and the selected tax treatment before calling the simple expense-based result cash FCFF. No unreported CFO allocation is invented.'))
 if t=='WMT':
  debt=choose(p,['InterestExpenseDebt'],mode='magnitude',caption=lambda c:c.strip().lower()=='debt')
  lease=choose(p,['FinanceLeaseAndFinancingObligationInterestExpense'],mode='magnitude',caption=lambda c:'finance lease' in c.lower())
  point=derived('GROSS_INTEREST_DEBT_PLUS_FINANCE_OBLIGATIONS',[(1,debt),(1,lease)],'Gross expensed interest = Debt + Finance lease/financing-obligation interest; separate FinanceLeaseInterestExpense is a subset and is not added twice.')
 if t=='CVX':point=choose(p,['InterestExpenseDebt'],mode='magnitude',caption=gross_caption)
 if t=='CAT':
  industrial=dimensioned_point(p,'InterestExpense','AllOtherExcludingFinancialProductsMember') or dimensioned_point(p,'InterestExpenseNonoperating','AllOtherExcludingFinancialProductsMember')
  financial=dimensioned_point(p,'FinancingInterestExpense','FinancialProductsMember')
  point=derived('CONSOLIDATED_INDUSTRIAL_PLUS_FINANCIAL_PRODUCTS_INTEREST',[(1,industrial),(1,financial)],'Industrial interest plus Financial Products interest, with the two explicitly disjoint business members preserved. The consolidated financing-business perimeter remains provisional.')
 if t=='PEP':
  matches=[r['point'] for r in SUPP if r['ticker']==t and r['fiscal_year']==p['fiscal_year'] and r['field']=='interest_expense']
  point=matches[0] if len(matches)==1 else None
  if point:flags.append(issue('GROSS_INTEREST_FROM_COMPANY_ROIC_TABLE','REVIEW',['FCFF'],'Gross interest is separately reported in the primary filing ROIC reconciliation, without an XBRL tag. The income-statement InterestExpense QName represents net interest and other and is not substituted.','Reconcile the ROIC interest definition, debt-redemption charges and any noncash amounts already added back in CFO before accepting an unqualified FCFF. The literal reported-ETR calculation is retained for review.'))
 if t=='META' and point is None:
  for comp in sorted([c for c in COMP if c['ticker']==t and c['target_identity']==p['identity']],key=lambda c:c['source_filing_identity']['annual_end']):
   q={**p,'instance':comp['instance'],'primary':comp['primary'],'source_filing_identity':comp['source_filing_identity']}
   point=choose(q,['InterestExpense','InterestExpenseNonoperating'],mode='magnitude',caption=gross_caption)
   if point:
    flags.append(issue('LATER_RETAINED_COMPARATIVE_INTEREST','NOTE',['FCFF'],'Separately disclosed gross interest is taken from a later retained annual filing for this exact fiscal period.','Retain both original-year and later comparative accession bindings; do not use net interest instead.'))
    break
 if t=='V' and point is None:
  # The economic caption is explicit in FY2022/23 despite a net-interest QName.
  point=choose(p,['InterestIncomeExpenseNet'],mode='magnitude',caption=lambda c:c.strip().lower()=='interest expense')
  if point:flags.append(issue('INTEREST_TAG_CAPTION_EXCEPTION','NOTE',['FCFF'],'The face caption is Interest expense, while its QName contains IncomeExpenseNet. The displayed caption controls this source-bound classification.','Preserve the QName and caption together; do not extend this exception to FY2021, whose caption explicitly says net.'))
  if point is None:
   for comp in sorted([r for r in COMP if r['ticker']==t and r['target_identity']==p['identity']],key=lambda r:r['source_filing_identity']['annual_end']):
    q={**p,'instance':comp['instance'],'primary':comp['primary'],'source_filing_identity':comp['source_filing_identity']}
    point=choose(q,['InterestIncomeExpenseNet'],mode='magnitude',caption=lambda caption:caption.strip().lower()=='interest expense')
    if point:
     flags.append(issue('LATER_VISA_REPORTED_INTEREST_LINE_PROXY','REVIEW',['FCFF'],'The original FY2021 caption says Interest expense, net. A later retained filing repeats the exact FY2021 amount as Interest expense. Its reported-line formula is saved provisionally; this does not establish a newly disclosed pure gross debt-interest amount.','Use the later exact target-period source binding for the displayed formula, and resolve the tax-interest/derivative components before accepting unlevered cash FCFF.'))
     break
 if t=='V':
  flags.append(issue('REPORTED_INTEREST_LINE_HAS_MIXED_COMPONENTS','REVIEW',['FCFF'],'Visa describes interest expense as including borrowing costs, interest on tax liabilities and derivative effects. Removing the word net from a later comparative caption does not establish a separate pure gross debt-interest amount. Available numerical years use the stated reported-expense line provisionally.','Reconcile debt interest, tax-liability interest and hedge gains/losses to cash-flow addbacks and the selected tax treatment. Do not add investment income from another line merely to manufacture gross interest.'))
 if point is None:flags.append(issue('MISSING_SEPARATE_GROSS_EXPENSED_INTEREST','BLOCKER',['FCFF'],'No sufficiently bound separately disclosed gross expensed interest has been selected; cash interest, net interest and coupon estimates are not substituted.','Find an explicit gross expense disclosure or reconstruct it from compatible separately reported expense components. Otherwise leave FCFF blank.'))
 return point,flags

TOTALS={'NetCashProvidedByUsedInFinancingActivities','NetCashProvidedByUsedInFinancingActivitiesContinuingOperations'}
def financing_sections(p):
 found=[]
 for d in p['primary']:
  tabs=d['tables'];chosen=[]
  for j,tab in enumerate(tabs):
   endings=[i for i,r in enumerate(tab['rows']) if any(f['concept'].split(':')[-1] in TOTALS and not f['dimensions'] for f in r['facts'])]
   for end in endings:
    starts=[i for i,r in enumerate(tab['rows'][:end]) if re.search(r'\bfinancing(?: activities)?\b',r['text'],re.I) and not r['facts']]
    path='EXPLICIT_FINANCING_HEADING'
    if starts:block=[dict(table=tab['table'],**r) for r in tab['rows'][starts[-1]+1:end+1]]
    else:
     investing=[i for i,r in enumerate(tab['rows'][:end]) if any(f['concept'].split(':')[-1] in ['NetCashProvidedByUsedInInvestingActivities','NetCashProvidedByUsedInInvestingActivitiesContinuingOperations'] for f in r['facts'])]
     if investing:block=[dict(table=tab['table'],**r) for r in tab['rows'][investing[-1]+1:end+1]];path='AFTER_INVESTING_SUBTOTAL'
     elif p['ticker']=='JNJ':
      # Same-document statement continuation, with an explicit earlier start.
      prior=[x for x in tabs[:j] if any(re.search(r'^Cash flows(?: \(used by\))? (?:from|\(used by\) from) financing activities$',r['caption'],re.I) for r in x['rows'])]
      if not prior:continue
      first=prior[-1];si=next(i for i,r in enumerate(first['rows']) if re.search(r'cash flows.*financing activities',r['caption'],re.I))
      block=[dict(table=first['table'],**r) for r in first['rows'][si+1:]]
      for middle in tabs:
       if first['table']<middle['table']<tab['table']:block.extend(dict(table=middle['table'],**r) for r in middle['rows'])
      block.extend(dict(table=tab['table'],**r) for r in tab['rows'][:end+1]);path='JNJ_EXPLICIT_SAME_DOCUMENT_CONTINUED_STATEMENT'
     else:continue
    found.append(dict(source=d['source'],context_source=d.get('context_source'),boundary=path,rows=block))
 return found

def classify(caption,concept,ticker):
 c=caption.lower();local=concept.split(':')[-1]
 if local in TOTALS:return 'FINANCING_TOTAL'
 if any(s in c for s in ['notes due from','note receivable','notes receivable']):return 'NONDEBT_RELATED_PARTY_ASSET'
 if 'credit support agreement' in c:return 'CREDIT_SUPPORT_COLLATERAL_NOT_DEBT'
 if 'overdraft' in c:return 'DEBT_FUNDING_OR_PRINCIPAL'
 if ticker=='CAT' and local in ['ProceedsFromDebtMaturingInMoreThanThreeMonths','RepaymentsOfDebtMaturingInMoreThanThreeMonths']:return 'DEBT_FUNDING_OR_PRINCIPAL'
 if any(v in c for v in ['treasury shares','treasury stock','share repurchases','share repurchase','stock repurchases','stock for treasury','issuances of stock','company stock','restricted stock','shares settled','stock compensation','common and capital stock','repurchases of stock','issuance of shares','issuances of shares','stock issued under equity']):return 'COMMON_EQUITY_OR_OTHER_OWNER_CASH'
 if 'stock option' in c or 'common stock' in c or 'common shares' in c or 'treasury stock' in c or 'ordinary shares' in c or 'equity award' in c or 'stock-based award' in c or 'stock plans' in c or 'employee stock' in c or 'equity incentive' in c or 'withholding' in c or 'shareholder settlement' in c or 'legal fees' in c:return 'COMMON_EQUITY_OR_OTHER_OWNER_CASH'
 if 'preferred stock' in c or 'preferred share' in c:return 'PREFERRED_CAPITAL_NOT_DEBT'
 if 'interest in consolidated entit' in c or 'subsidiary stock' in c or 'noncontrolling' in c or 'non-controlling' in c or 'partner contribution' in c or 'subsidiary shares' in c or 'mobileye ipo' in c:return 'NONCONTROLLING_CAPITAL_NOT_DEBT'
 if 'dividend' in c:return 'DIVIDENDS_NOT_NET_BORROWING'
 if 'transfers from' in c or 'transfers to' in c or 'distribution from' in c or 'cash transferred' in c or 'initial public offering' in c:return 'SEPARATION_OR_EQUITY_NOT_BORROWING'
 if 'contingent consideration' in c or 'purchase consideration' in c:return 'ACQUISITION_SETTLEMENT_NOT_DEBT'
 if 'derivative' in c:return 'DERIVATIVE_COLLATERAL_NOT_BORROWING'
 if 'customer contract liability' in c:return 'CUSTOMER_FUNDING_REVIEW'
 if 'finance lease' in c and ('debt' in c or 'borrowing' in c):return 'COMBINED_DEBT_AND_LEASE_PRINCIPAL'
 if re.search(r'(?:debt|borrowing|financing) (?:issuance|restructuring|exchange|redemption).*cost|debt issuance costs|cash premium on debt exchange|premium.*extinguish debt',c):return 'DEBT_TRANSACTION_COST_CASH'
 if 'finance lease' in c or 'financing lease' in c:
  if 'other financing' in c:return 'MIXED_LEASE_OTHER_FINANCING'
  if 'debt' in c or 'borrowing' in c:return 'COMBINED_DEBT_AND_LEASE_PRINCIPAL'
  return 'LEASE_PRINCIPAL'
 if 'equipment purchase contract' in c or 'principal payments on property' in c:return 'FINANCED_ASSET_PRINCIPAL'
 if ticker=='INTC' and c.startswith('additions to property'):return 'FINANCED_ASSET_CASH_SETTLEMENT'
 if 'short-term debt, and other' in c:return 'MIXED_DEBT_OTHER_FINANCING'
 if 'net of capped call' in c:return 'MIXED_DEBT_DERIVATIVE_SETTLEMENT'
 if re.search(r'debt|borrow|commercial paper|credit facilit|notes due to|financing obligation|long-term financing|short-term financing|senior notes|credit agreements|collateralized lease repayment',c):return 'DEBT_FUNDING_OR_PRINCIPAL'
 if re.search(r'ProceedsFrom(?:ShortTermDebt|RepaymentsOfShortTermDebt)|RepaymentsOfShortTermDebt',local):return 'DEBT_FUNDING_OR_PRINCIPAL'
 if c in ['more than three months - proceeds','more than three months - payments','three months or less, net'] or 'maturities of 90 days or less' in c or 'maturities longer than 90 days' in c:return 'DEBT_FUNDING_OR_PRINCIPAL'
 if 'financing activities from discontinued operations' in c:return 'DISCONTINUED_FINANCING_UNALLOCATED'
 if 'other' in c:return 'OTHER_FINANCING_EXCLUDED'
 return 'UNCLASSIFIED_FINANCING_ROW'

DEBT_CLASSES={'DEBT_FUNDING_OR_PRINCIPAL','DEBT_TRANSACTION_COST_CASH','LEASE_PRINCIPAL','COMBINED_DEBT_AND_LEASE_PRINCIPAL','FINANCED_ASSET_PRINCIPAL','FINANCED_ASSET_CASH_SETTLEMENT','MIXED_DEBT_OTHER_FINANCING','MIXED_DEBT_DERIVATIVE_SETTLEMENT'}
def financing(p):
 sections=financing_sections(p);flags=[];schedules=[]
 if len(sections)!=1:
  return None,sections,[issue('FINANCING_SECTION_NOT_UNIQUELY_BOUND','BLOCKER',['FCFE'],f'Expected one independently bound face financing section; found {len(sections)}.','Bind the selected source and any explicit continuation; do not sum debt notes or infer zeros.')]
 s=sections[0];total=None;component=Fraction(0);debt=Fraction(0);valid=True;debtrows=0
 for r in s['rows']:
  ff=r['facts']
  if not ff:continue
  # CAT has mutually exclusive industrial/Financial Products rows on its
  # consolidated face statement. Keep dimensions and the scope warning.
  eligible=[f for f in ff if not f['dimensions'] or p['ticker']=='CAT']
  if not eligible:continue
  if len(eligible)!=1:
   valid=False;flags.append(issue('MULTIPLE_CURRENT_FINANCING_ROW_VALUES','REVIEW',['FCFE'],f"Ambiguous face row: {r['caption']}",'Resolve the exact annual consolidated column before accepting the row.'));continue
  f=eligible[0];v=Fraction(f['displayed_value_usd']);cl=classify(r['caption'],f['concept'],p['ticker'])
  raw=[x for x in p['instance']['facts'] if x['concept']==f['concept'].split(':')[-1] and x['context_id']==f['context_id'] and abs(Fraction(x['value_usd']))==abs(v)]
  row=dict(ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=p['identity']['annual_end'],caption=r['caption'],classification=cl,value_usd=dec(v),included_in_net_borrowing=cl in DEBT_CLASSES,table=r['table'],row=r['row'],primary_fact=f,source=s['source'],instance_source=p['instance']['source'],instance_observations=raw)
  schedules.append(row)
  if not raw:
   valid=False;flags.append(issue('FINANCING_PRIMARY_INSTANCE_BINDING_GAP','REVIEW',['FCFE'],f"No exact instance binding selected for the displayed row {r['caption']}.",'Verify context/namespace and the original face cell; no automatic numeric match across contexts.'))
  if cl=='FINANCING_TOTAL':total=v;continue
  component+=v
  if cl in DEBT_CLASSES:debt+=v;debtrows+=1
  if cl in ['MIXED_DEBT_OTHER_FINANCING','MIXED_DEBT_DERIVATIVE_SETTLEMENT'] and v:
   flags.append(issue(cl,'REVIEW',['FCFE'],f"Included only as a provisional cash-funding subtotal: {r['caption']} ({dec(v)} USD).",'Separate the non-borrowing component using the debt and cash-flow notes; no residual allocation.'))
  if cl=='MIXED_LEASE_OTHER_FINANCING' and v:flags.append(issue(cl,'NOTE',['FCFE'],'Mixed lease/other row is excluded; use separately reported lease principal when it can be bound.','Match the lease cash disclosure to the mixed parent row; never add both.'))
  if cl in ['UNCLASSIFIED_FINANCING_ROW','DISCONTINUED_FINANCING_UNALLOCATED'] and v:
   flags.append(issue('UNCLASSIFIED_FINANCING_CASH','REVIEW',['FCFE'],f"Unclassified financing row excluded: {r['caption']} ({dec(v)} USD).",'Classify the source caption and notes; do not force it into debt.'))
  if cl=='OTHER_FINANCING_EXCLUDED' and v:flags.append(issue('OTHER_FINANCING_EXCLUDED','REVIEW',['FCFE'],f"Nonzero Other financing is not fully decomposed in this research schedule: {r['caption']} ({dec(v)} USD). It is excluded rather than assumed to be debt or assumed to contain no debt.",'Bind a complete note-level decomposition or document an explicit materiality/scope decision. Separately identified lease principal is included once, but that alone does not resolve all residual Other financing cash.'))
  if cl in ['NONCONTROLLING_CAPITAL_NOT_DEBT','PREFERRED_CAPITAL_NOT_DEBT'] and v:
   flags.append(issue('NONCOMMON_CAPITAL_SCOPE','REVIEW',['FCFE'],f"Reported noncommon capital cash is excluded from net borrowing: {r['caption']} ({dec(v)} USD).",'Reconcile common-equity attribution and preferred/NCI claims before treating this consolidated cash-flow measure as cash available solely to parent common shareholders.'))
  if cl=='CUSTOMER_FUNDING_REVIEW' and v:flags.append(issue('CUSTOMER_ADVANCES_CLASSIFIED_AS_FINANCING','REVIEW',['FCFF','FCFE'],f"Customer contract liability deposits of {dec(v)} USD are reported in financing, not included in either CFO or debt borrowing in this baseline.",'Review the contractual financing versus operating nature, repayment/delivery obligations and forecast treatment; quantify any justified reclassification separately.'))
 # Separately reported finance-lease principal can be inside Other or a combined debt row.
 lease=choose(p,['FinanceLeasePrincipalPayments','FinanceLeasePrincipalPaymentsNet'],mode='magnitude')
 explicit_lease=any(r['classification'] in ['LEASE_PRINCIPAL','COMBINED_DEBT_AND_LEASE_PRINCIPAL'] for r in schedules)
 if lease and not explicit_lease:
  if p['ticker'] in ['COST','MSFT']:
   # The lease cash note supplies an amount buried in the separate Other/mixed row.
   val=-Fraction(lease['value_usd']);debt+=val
   schedules.append(dict(ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=p['identity']['annual_end'],caption='Separately disclosed finance-lease principal (not a second face financing row)',classification='LEASE_NOTE_PRINCIPAL_COMPONENT',included_in_net_borrowing=True,value_usd=dec(val),point=lease,not_added_to_financing_total=True))
   flags.append(issue('LEASE_PRINCIPAL_FROM_NOTE','NOTE',['FCFE'],'Separately disclosed finance-lease principal is included once; the Other/mixed face row is excluded from net borrowing.','Preserve note-to-face containment evidence and the principal versus interest distinction.'))
  elif p['ticker']=='GOOGL':
   flags.append(issue('LEASE_PRINCIPAL_ALREADY_IN_DEBT_REPAYMENTS','NOTE',['FCFE'],'Alphabet explicitly states that finance-lease financing cash flows are included in repayments of debt. The complete repayment parent is included once.','Do not deduct separate lease principal again. Retain Note Leases footnote (1) and the original repayment QName.'))
  elif p['ticker'] in ['HD','MU']:
   # Do not choose an extra deduction until the combined-debt caption is resolved.
   flags.append(issue('LEASE_PRINCIPAL_PARENT_SCOPE_UNRESOLVED','REVIEW',['FCFE'],f"Lease principal {lease['value_usd']} USD is separately disclosed; the debt row may already contain it.",'Confirm parent/child containment from the debt/lease notes; then include once. Current provisional result uses face debt rows without an extra lease deduction.',lease_principal_usd=lease['value_usd']))
  else:flags.append(issue('LEASE_PRINCIPAL_NOT_IN_SELECTED_FACE_DEBT','REVIEW',['FCFE'],'Separate lease principal exists outside the selected face debt rows.','Determine whether it is a component of selected debt or Other; include it once.'))
 if total is None:flags.append(issue('MISSING_FINANCING_TOTAL','REVIEW',['FCFE'],'Financing section total not selected.','Bind the annual financing total.'))
 elif component!=total:flags.append(issue('FINANCING_COMPONENTS_DO_NOT_TIE','REVIEW',['FCFE'],f'Displayed financing components differ from total by {dec(component-total)} USD.','Inspect original cells/rounding/continuations; do not plug or silently waive the difference.',difference_usd=dec(component-total)))
 if not debtrows:
  flags.append(issue('NO_EXPLICIT_DEBT_CASH_ROWS','BLOCKER',['FCFE'],'No debt cash-flow row is selected; this is not a zero-borrowing conclusion.','Use an explicit no-borrowing/no-outstanding-balance note plus the complete statement before establishing zero.'))
  return None,dict(section=s,rows=schedules,total_usd=dec(total) if total is not None else None,components_usd=dec(component),disclosed_lease_principal=lease),flags
 if not valid:flags.append(issue('FINANCING_ROW_BINDING_REVIEW','REVIEW',['FCFE'],'At least one financing row lacks an unambiguous exact raw binding.','Resolve the underlying row before accepting the net funding schedule.'))
 return dict(value_usd=dec(debt),unit='USD',definition='Sum of selected, non-overlapping displayed debt receipts, principal/lease repayments and separately displayed debt transaction cash costs; not balance-sheet debt change or total CFF.'),dict(section=s,rows=schedules,total_usd=dec(total) if total is not None else None,components_usd=dec(component),disclosed_lease_principal=lease),flags

def investing_rows(p):
 """Face investing rows, excluding operating add-backs and noncash supplements."""
 out=[]
 for d in p['primary']:
  for tab in d['tables']:
   roots=[i for i,r in enumerate(tab['rows']) if any(f['concept'].split(':')[-1]=='NetCashProvidedByUsedInInvestingActivities' and not f['dimensions'] for f in r['facts'])]
   ends=roots or [i for i,r in enumerate(tab['rows']) if any(f['concept'].split(':')[-1]=='NetCashProvidedByUsedInInvestingActivitiesContinuingOperations' and not f['dimensions'] for f in r['facts'])]
   if len(ends)!=1:continue
   end=ends[0]
   starts=[i for i,r in enumerate(tab['rows'][:end]) if 'investing' in r['text'].lower() and not r['facts']]
   if not starts:
    starts=[i for i,r in enumerate(tab['rows'][:end]) if any(f['concept'].split(':')[-1].startswith('NetCashProvidedByUsedInOperatingActivities') and not f['dimensions'] for f in r['facts'])]
   if not starts:continue
   for r in tab['rows'][starts[-1]+1:end]:
    for f in r['facts']:
     if f['dimensions']:continue
     raw=[x for x in p['instance']['facts'] if x['concept']==f['concept'].split(':')[-1] and x['context_id']==f['context_id'] and abs(Fraction(x['value_usd']))==abs(Fraction(f['displayed_value_usd']))]
     if not raw:continue
     out.append(dict(caption=r['caption'],value_usd=f['displayed_value_usd'],concept=f['concept'].split(':')[-1],target_period={k:p['identity'][k] for k in ('cik','annual_start','annual_end')},source_filing_identity=p['source_filing_identity'],instance=dict(source=p['instance']['source'],observations=raw),primary=[dict(source=d['source'],table=tab['table'],row=r['row'],caption=r['caption'],**f)],evidence_depth='EXACT_FACE_INVESTING_ROW_AND_INSTANCE'))
 return out

def expanded_investment(p,cap):
 """Quantify named cash adjustments; no unreported split of Other or acquisitions."""
 if cap is None:return None,[],[]
 rows=investing_rows(p);adjustments=[];flags=[];seen=set()
 for point in rows:
  c=point['caption'].lower();con=point['concept'];cash=Fraction(point['value_usd'])
  if con==cap['concept']:continue
  action=None
  if p['ticker']=='CAT' and con in ['PaymentsToAcquireEquipmentOnLease','PaymentsToAcquireFinanceReceivables','ProceedsFromCollectionOfFinanceReceivables','ProceedsFromSaleOfFinanceReceivables']:action='CONSOLIDATED_FINANCING_ASSET_INVESTMENT'
  elif p['ticker'] in ['IBM','MA'] and re.search(r'^(?:investment in software|capitalized software)$',c):action='ADDITIONAL_CAPITALIZED_SOFTWARE'
  elif p['ticker']=='VZ' and 'acquisitions of wireless licenses' in c:action='ADDITIONAL_WIRELESS_LICENSE_INVESTMENT'
  elif p['ticker']=='KLAC' and 'acquisition of intellectual property' in c:action='ADDITIONAL_INTELLECTUAL_PROPERTY_INVESTMENT'
  elif p['ticker']=='LLY' and 'purchases of in-process research and development' in c:action='ADDITIONAL_ACQUIRED_DEVELOPMENT_INVESTMENT'
  elif con=='ProceedsFromSaleOfPropertyPlantAndEquipment' and p['ticker']!='TSLA':action='FIXED_ASSET_DISPOSAL_RECEIPT'
  elif p['ticker']=='AMZN' and 'property and equipment sales and incentives' in c:action='REPORTED_PPE_SALES_AND_INCENTIVES_RECEIPT'
  elif p['ticker'] in ['PEP','PG','TXN'] and con=='ProceedsFromSaleOfProductiveAssets':action='REPORTED_FIXED_ASSET_SALE_RECEIPT'
  elif p['ticker'] in ['INTC','MU','TXN'] and re.search(r'proceeds from.*(?:incentives|grants|assistance)',c):action='REPORTED_CAPITAL_INCENTIVE_RECEIPT'
  elif p['ticker']=='IBM' and con=='NonOperatingFinanceReceivablesNet':action='NONOPERATING_FINANCE_RECEIVABLE_INVESTMENT'
  elif p['ticker']=='IBM' and con=='ProceedsFromSaleOfProductiveAssets':
   flags.append(issue('MIXED_PPE_OTHER_DISPOSAL_RECEIPT','REVIEW',['FCFF','FCFE'],'IBM discloses combined PP&E/other disposition cash, which is not allocated to the fixed-capital variant.','Separate the other investment/disposal component before including it as pure fixed-capital proceeds.'))
  elif p['ticker'] in ['CVX','LIN'] and re.search(r'asset sales|divestitures',c) and cash:
   flags.append(issue('MIXED_DIVESTMENT_RECEIPTS_NOT_ALLOCATED','NOTE',['FCFF','FCFE'],'Business divestitures/asset sales/returns of investments share a reported cash row; no pure fixed-asset split is invented.','Retain the mixed proceeds outside the identified fixed-capital calculation until the investment note supplies an exact split.'))
  elif re.search(r'licenses|milestones',c) and 'other' in c and cash:
   flags.append(issue('MIXED_CAPITALIZED_LICENSE_MILESTONE_CASH','REVIEW',['FCFF','FCFE'],f"Mixed investing cash excluded from both measures: {point['caption']} ({point['value_usd']} USD).",'Disaggregate the capitalized licenses/milestones versus other investing cash from the retained notes.'))
  if action:
   key=(point['primary'][0]['source']['url'],point['primary'][0]['table'],point['primary'][0]['row'])
   if key in seen:continue
   seen.add(key);adjustments.append(dict(action=action,cash_flow_usd=dec(cash),investment_delta_usd=dec(-cash),point=point))
   if cash and action.startswith('ADDITIONAL_'):flags.append(issue(action,'REVIEW',['FCFF','FCFE'],f"Separately reported investment cash is outside the platform cash-capex baseline: {point['caption']} ({point['value_usd']} USD).",'The expanded investment variant includes this exact amount. Decide and document the desired investment perimeter before changing platform history.',investment_delta_usd=dec(-cash)))
   elif cash:flags.append(issue('IDENTIFIED_INVESTMENT_VARIANT_ADJUSTMENT','NOTE',['FCFF','FCFE'],f"The expanded investment variant additionally uses {point['caption']} ({point['value_usd']} USD); the baseline selected cash-capex amount stays unchanged.",'Preserve the original investment caption and source. Use a consistent gross/net investment convention across years; do not treat a presentation change as new cash generation.',investment_delta_usd=dec(-cash)))
 value=Fraction(cap['value_usd'])+sum((Fraction(a['investment_delta_usd']) for a in adjustments),Fraction(0))
 return dict(value_usd=dec(value),unit='USD',definition='Baseline reported cash capex plus identified separate software/IP/wireless-license, acquired development and financing-asset cash investment, less identified fixed-asset disposal receipts and capital incentives. Business acquisitions, securities investment and unallocated mixed captions are excluded. This is an explicitly broader investment variant, not an assertion that every development purchase is PP&E.',base=cap,adjustments=adjustments),rows,flags

def separately_reported_noncash_financing_addbacks(p):
 """Explicit operating cash-flow adjustments, not arbitrary debt-note amortization."""
 out=[];seen=set()
 for doc in p['primary']:
  for tab in doc['tables']:
   roots=[i for i,r in enumerate(tab['rows']) if any(f['concept'].split(':')[-1].startswith('NetCashProvidedByUsedInOperatingActivities') and not f['dimensions'] for f in r['facts'])]
   if not roots:continue
   for r in tab['rows'][:roots[0]]:
    if not re.search(r'amorti.*(?:debt|bond|financing).*(?:cost|discount|premium)|(?:debt|bond|financing).*(?:cost|discount|premium).*amorti',r['caption'],re.I):continue
    for f in r['facts']:
     if f['dimensions']:continue
     raw=[x for x in p['instance']['facts'] if x['concept']==f['concept'].split(':')[-1] and x['context_id']==f['context_id'] and abs(Fraction(x['value_usd']))==abs(Fraction(f['displayed_value_usd']))]
     if not raw:continue
     k=(doc['source']['url'],tab['table'],r['row'],f['cell'])
     if k in seen:continue
     seen.add(k);out.append(dict(caption=r['caption'],value_usd=f['displayed_value_usd'],concept=f['concept'].split(':')[-1],target_period={k:p['identity'][k] for k in ('cik','annual_start','annual_end')},source_filing_identity=p['source_filing_identity'],instance=dict(source=p['instance']['source'],observations=raw),primary=[dict(source=doc['source'],table=tab['table'],row=r['row'],caption=r['caption'],**f)],evidence_depth='EXPLICIT_OPERATING_CASHFLOW_NONCASH_FINANCING_ADJUSTMENT'))
 return out

def calculate(p):
 flags=[];t=p['ticker']
 cfo=choose(p,['NetCashProvidedByUsedInOperatingActivities','NetCashProvidedByUsedInOperatingActivitiesContinuingOperations'],mode='cash')
 cap=choose(p,CAPEX.get(t,['PaymentsToAcquirePropertyPlantAndEquipment']),mode='magnitude')
 tax=choose(p,['IncomeTaxExpenseBenefit'])
 pretax=choose(p,PRETAX)
 intr,iff=interest(p);flags+=iff
 cash_interest=choose(p,['InterestPaidNet','InterestPaid'],mode='magnitude',caption=lambda text:'interest' in text.lower() and 'tax' not in text.lower() and any(word in text.lower() for word in ['paid','payments']))
 debt,fin,ff=financing(p);flags+=ff
 expanded,investing,investment_flags=expanded_investment(p,cap);flags+=investment_flags
 noncash_financing=separately_reported_noncash_financing_addbacks(p)
 for nc in noncash_financing:
  if Fraction(nc['value_usd']):flags.append(issue('NONCASH_FINANCING_COST_ALREADY_ADDED_BACK_IN_CFO','REVIEW',['FCFF'],f"CFO separately adjusts {nc['caption']} ({nc['value_usd']} USD). If this is also included in selected interest expense, the simple expense-based interest addback can count it twice.",'Reconcile the interest-expense components to the operating cash-flow addback and cash interest/tax treatment before accepting an adjusted FCFF. No automatic subtraction or allocation is imposed.'))
 for name,v,aff in [('CFO',cfo,['FCFF','FCFE']),('cash capital investment',cap,['FCFF','FCFE']),('tax provision',tax,['FCFF']),('pretax income',pretax,['FCFF'])]:
  if v is None:flags.append(issue('MISSING_'+name.upper().replace(' ','_'),'BLOCKER',aff,'No unambiguous exact reported '+name+' selected.','Resolve the caption, annual entity context and raw body binding; never fill missing with zero.'))
 if cfo and 'ContinuingOperations' in cfo['concept']:flags.append(issue('CONTINUING_OPERATIONS_CFO','NOTE',['FCFF','FCFE'],'CFO is explicitly continuing operations, not a missing consolidated root or an interchangeable consolidated total.','Keep investment, financing and tax on the same continuing-operations perimeter; retain the period-specific scope.'))
 if cap:
  captions=sorted({f['caption'] for f in cap['primary']});cap['economic_caption']=captions
  if any(re.search(r'intangible|software|technology',c,re.I) for c in captions):flags.append(issue('COMBINED_REPORTED_FIXED_ASSET_INVESTMENT','NOTE',['FCFF','FCFE'],'Reported investment combines PP&E with intangibles/software/technology; the cash amount is reported, not an estimated PP&E split.','Keep the broader investment caption visible; do not relabel it pure PP&E.'))
  if t=='TSLA':flags.append(issue('REPORTED_NET_CASH_PPE','NOTE',['FCFF','FCFE'],'The source PP&E purchase caption is already net of sales and excludes finance leases.','Do not subtract sale proceeds a second time or call this gross investment.'))
 rate=None;fcff=None;fcfe=None;cashfcf=None
 if cfo and cap:cashfcf=Fraction(cfo['value_usd'])-Fraction(cap['value_usd'])
 if tax and pretax:
  pre=Fraction(pretax['value_usd'])
  if pre:rate=Fraction(tax['value_usd'])/pre
  if pre<=0:flags.append(issue('NONPOSITIVE_PRETAX_TAX_SHIELD_UNJUSTIFIED','REVIEW',['FCFF'],'A reported loss/zero pretax amount does not establish a realized marginal interest tax shield.','Review tax disclosures and cash-tax effects. Keep any literal reported-ETR arithmetic provisional; do not apply an invented statutory rate or clamp.'))
  if rate is not None and not 0<=rate<=1:flags.append(issue('REPORTED_ETR_OUTSIDE_ZERO_ONE','REVIEW',['FCFF'],f'Reported provision / pretax = {dec(rate)}. Literal arithmetic is not evidence that interest is subsidized at this rate.','Review tax benefits, valuation allowances and discrete events. No automatic clamp or normalization.'))
 if cashfcf is not None and intr and rate is not None:fcff=cashfcf+Fraction(intr['value_usd'])*(1-rate)
 if cashfcf is not None and debt:fcfe=cashfcf+Fraction(debt['value_usd'])
 if p['history_origin']!='SELECTED_ANNUAL':flags.append(issue('RECOVERED_CARVEOUT_COMPARATIVE','REVIEW',['FCFF','FCFE'],'Additional historical year is recovered from a retained comparative column; it is pre-separation/carve-out history.','Preserve original parent allocations/transfers and do not present the series as five standalone public-company annuals.'))
 # Company/perimeter-specific economic constraints, independent of arithmetic.
 if t=='CAT':flags.append(issue('CAPTIVE_FINANCE_PERIMETER','REVIEW',['FCFF','FCFE'],'Consolidated CFO includes Financial Products; ordinary PP&E excludes equipment leased to others and finance-receivable investment.','Use a consistent industrial/captive-finance split or an explicit consolidated financing-company investment model. Generic baseline results are provisional.'))
 if t=='IBM':flags.append(issue('FINANCING_BUSINESS_PERIMETER','REVIEW',['FCFF','FCFE'],'Consolidated cash flow includes a financing business and non-operating finance receivables outside the selected PP&E investment.','Align the financing-asset cash investment and associated debt/interest perimeter; do not certify an operating-company FCFF from this subtotal alone.'))
 if t=='JNJ' and p['fiscal_year']==2023:flags.append(issue('KENVUE_DISCONTINUED_SCOPE','REVIEW',['FCFF','FCFE'],'Consolidated cash flows include Kenvue separation/discontinued cash while selected pretax/interest are continuing-operations figures. Debt transferred to Kenvue is separately flagged.','Bind continuing versus discontinued CFO, investment, interest/taxes and transferred debt before accepting a current-business series.'))
 nci=choose(p,['NetIncomeLossAttributableToNoncontrollingInterest'])
 if nci and Fraction(nci['value_usd']) and not any(i['code']=='NONCOMMON_CAPITAL_SCOPE' for i in flags):flags.append(issue('NONCONTROLLING_CASH_ATTRIBUTION_UNRESOLVED','REVIEW',['FCFE'],f"Consolidated CFO is not separately allocated to parent common equity; reported NCI earnings are {nci['value_usd']} USD. NCI earnings are not substituted for NCI cash flow.",'Reconcile the subsidiary/NCI cash perimeter or value NCI separately. A disclosed NCI dividend alone does not establish its full share of FCFE.'))
 pref=choose(p,['PreferredStockDividendsIncomeStatementImpact','DividendsPreferredStock'])
 if pref and Fraction(pref['value_usd']):flags.append(issue('PREFERRED_CLAIM_CASH_TREATMENT','REVIEW',['FCFE'],f"A preferred dividend/EPS deduction of {pref['value_usd']} USD is disclosed; it is not automatically cash paid. Baseline FCFE is before this additional noncommon claim.",'Use separately reported preferred cash dividends where available. For ESOP shares and accrued dividends, prevent a second deduction of amounts already in CFO.'))
 if t in ['GEV','SNDK']:flags.append(issue('CARVEOUT_AND_PARENT_FUNDING','REVIEW',['FCFF','FCFE'],'Carve-out/parent transfers and standalone separation affect historical financing comparability; parent transfers are not ordinary borrowing.','Retain separately reported notes payable versus notes receivable and parent equity transfers. Resolve the standalone cash-flow perimeter.'))
 if t=='PLTR' and p['fiscal_year'] in [2021,2022]:flags.append(issue('SOURCE_TAG_CAPTION_MISMATCH_RESOLVED_FOR_RESEARCH','NOTE',['FCFE'],'Debt-proceeds QName is attached to option-exercise proceeds; the actual debt issuance caption has another QName. Classification follows independently inspected displayed rows, preserving both facts.','Register this exact source-bound exception before any production normalization change.'))
 vintage=[r for r in VINTAGES['differences'] if r['ticker']==t and r['target_identity']==p['identity']]
 changed=[r for r in vintage if r['classification']=='LATER_COMPARATIVE_AMOUNT_CHANGE']
 if changed:flags.append(issue('LATER_COMPARATIVE_AMOUNTS_DIFFER','REVIEW',['FCFF','FCFE'],'A later retained filing reports different amounts for '+', '.join(sorted({r['field'] for r in changed}))+'. Original selected as-filed operands remain unchanged in this study.','Choose a consistent source vintage/business perimeter and bind the full calculation to it. Review the saved later primary cells; do not overwrite just one operand or assume every difference is a restatement.',comparative_evidence=changed))
 status=lambda metric,value: 'UNAVAILABLE' if value is None else 'PROVISIONAL_REVIEW_REQUIRED' if any(x['severity'] in ['BLOCKER','REVIEW'] and metric in x['affects'] for x in flags) else 'SUPPORTED_UNDER_STATED_REPORTED_CASH_CONVENTION'
 preferred_cash=choose(p,['PaymentsOfDividendsPreferredStockAndPreferenceStock'],mode='magnitude',caption=lambda c:'preferred' in c.lower() and 'dividend' in c.lower())
 before_preferred=fcfe
 after_pref=None if fcfe is None or preferred_cash is None else fcfe-Fraction(preferred_cash['value_usd'])
 if after_pref is not None:
  fcfe=after_pref
  flags=[i for i in flags if i['code']!='PREFERRED_CLAIM_CASH_TREATMENT']
  flags.append(issue('REPORTED_PREFERRED_CASH_DIVIDENDS_DEDUCTED','NOTE',['FCFE'],f"Separately reported preferred cash dividends of {preferred_cash['value_usd']} USD are deducted after net borrowing. A declared/EPS preferred dividend is not substituted for cash paid.",'Preserve this additional deduction and its actual-payment source when comparing with the debt-only FCFE identity.'))
 expanded_delta=Fraction(expanded['value_usd'])-Fraction(cap['value_usd']) if expanded and cap else None
 expanded_fcff=None if fcff is None or expanded_delta is None else fcff-expanded_delta
 expanded_fcfe=None if fcfe is None or expanded_delta is None else fcfe-expanded_delta
 return dict(ticker=t,fiscal_year=p['fiscal_year'],identity=p['identity'],source_filing_identity=p.get('source_filing_identity'),history_origin=p['history_origin'],inputs=dict(cfo=cfo,cash_capex=cap,interest_expense=intr,tax_provision=tax,pretax_income=pretax,net_borrowing=debt,preferred_cash_dividends=preferred_cash),supporting_claims=dict(nci_earnings_not_cash=nci,preferred_earnings_or_declared_not_cash=pref),reported_cash_interest_for_basis_review=cash_interest,noncash_financing_addbacks=noncash_financing,cash_fcf=exact(cashfcf),reported_etr=None if rate is None else dec(rate),fcff=exact(fcff),fcfe=exact(fcfe),fcfe_before_disclosed_preferred_cash=exact(before_preferred),fcff_status=status('FCFF',fcff),fcfe_status=status('FCFE',fcfe),identified_expanded_investment=expanded,investing_rows=investing,expanded_fcff=exact(expanded_fcff),expanded_fcfe=exact(expanded_fcfe),fcfe_after_disclosed_preferred_cash=exact(after_pref),comparative_checks=vintage,issues=flags,financing=fin,source_instance=p['instance']['source'])

if __name__=='__main__':
 results=[calculate(p) for p in sorted(E['periods'],key=lambda p:(p['ticker'],p['fiscal_year'] or 0,p['identity']['annual_end']))]
 (OUT/'calculations-draft.json').write_text(json.dumps(dict(rule_version=RULE_VERSION,scope='Historical reported cash-flow research; no missing amount estimates; no platform acceptance; baseline cash-capex convention plus explicit net funding',periods=results),indent=2)+'\n')
 for t in sorted({p['ticker'] for p in results}):
  rr=[p for p in results if p['ticker']==t]
  print(t,' | '.join(f"FY{p['fiscal_year']} FCFF:{p['fcff_status'].split('_')[0]} {None if not p['fcff'] else round(float(p['fcff']['decimal_usd'])/1e9,3)} FCFE:{p['fcfe_status'].split('_')[0]} {None if not p['fcfe'] else round(float(p['fcfe']['decimal_usd'])/1e9,3)}" for p in rr))
 print('STATUS',dict(Counter(p['fcff_status'] for p in results)),dict(Counter(p['fcfe_status'] for p in results)))
