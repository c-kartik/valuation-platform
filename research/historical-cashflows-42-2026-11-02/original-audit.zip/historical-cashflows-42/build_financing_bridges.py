"""Exact, fully specified component reconciliations. No residual plug."""
from pathlib import Path
from fractions import Fraction
import json,csv,re
OUT=Path(__file__).resolve().parent
old=json.loads((OUT/'calculations-draft.json').read_text())
new=json.loads((OUT/'financing-comparative-calculations.json').read_text())
validation=json.loads((OUT/'financing-comparative-validation.json').read_text());assert not validation['errors']
def period(data,t,y):return next(p for p in data['periods'] if p['ticker']==t and p['fiscal_year']==y)
def term(data,t,y,pattern):
 p=period(data,t,y);rr=[r for r in p['financing']['rows'] if re.search(pattern,r['caption'],re.I) and not r.get('not_added_to_financing_total')]
 assert len(rr)==1,(t,y,pattern,[r['caption'] for r in rr])
 return dict(source_filing_identity=p['source_filing_identity'],target_identity=p['identity'],row=rr[0])
cases=[
 ('ORCL',2025,[(old,r'^Other financing activities, net$')],[(new,r'^Proceeds from short-term financing related to capital expenditures, net$'),(new,r'^Other financing activities, net$')],'A later filing separately identifies capital-expenditure financing receipts. The original Other amount reconciles to that receipt plus the later residual Other cash. The residual remains unallocated.'),
 ('COST',2022,[(old,r'^Other financing activities, net$')],[(new,r'^Proceeds from short-term borrowings$'),(new,r'^Repayments of short-term borrowings$'),(new,r'^Financing lease payments$'),(new,r'^Other financing activities, net$')],'The original Other amount reconciles to separately reported short-term borrowing cash, lease principal and residual Other. The original research already deducts the separately disclosed lease principal, but lacks the newly explicit net short-term receipts.'),
 ('VZ',2023,[(old,r'^Other, net$'),(old,r'^Net proceeds from \(repayments of\) short-term commercial paper$')],[(new,r'^Other, net$')],'The earlier explicit commercial-paper repayment is no longer separately displayed in the later presentation. Do not drop the known repayment by selecting only later explicit debt rows.'),
 ('MU',2024,[(old,r'^Other$'),(old,r'^Payments on equipment purchase contracts$')],[(new,r'^Other$'),(new,r'^Repurchases of common stock - withholdings on employee equity awards$')],'Equipment-purchase-contract principal and stock-award withholding are presented differently across the two versions. The cash amounts reconcile, but a later explicit-debt-only selection omits the earlier known principal.'),
 ('AAPL',2021,[(old,r'^Other$'),(old,r'^Proceeds from issuance of common stock$')],[(new,r'^Other$')],'Earlier common-stock proceeds are no longer separately displayed in the later financing presentation. Positive Other cash is not automatically borrowing.'),
]
bridges=[]
for ticker,year,left,right,note in cases:
 ll=[term(data,ticker,year,pattern) for data,pattern in left];rr=[term(data,ticker,year,pattern) for data,pattern in right]
 amount=lambda ss:sum((Fraction(z['row']['value_usd']) for z in ss),Fraction(0))
 a,b=amount(ll),amount(rr);assert a==b
 bridges.append(dict(ticker=ticker,fiscal_year=year,left_terms=ll,right_terms=rr,left_total_usd=str(a.numerator),right_total_usd=str(b.numerator),difference_usd='0',interpretation=note,limit='An exact component reconciliation supports presentation review; it does not certify the content of any remaining mixed Other cash or replace a source-vintage approval.'))
(OUT/'financing-component-reconciliations.json').write_text(json.dumps(dict(scope='Five exact component reconciliations using independently replayed original and later primary cash-flow cells. No inferred component, missing zero or residual plug.',bridges=bridges),indent=2)+'\n')
candidates=[]
for ticker,year in [('COST',2022),('ORCL',2025)]:
 a,b=period(old,ticker,year),period(new,ticker,year)
 candidates.append(dict(ticker=ticker,fiscal_year=year,annual_end=a['identity']['annual_end'],original_selected_fcfe_usd=a['fcfe']['decimal_usd'],later_disaggregated_fcfe_candidate_usd=b['fcfe']['decimal_usd'],original_net_funding_usd=a['inputs']['net_borrowing']['value_usd'],later_disaggregated_net_funding_usd=b['inputs']['net_borrowing']['value_usd'],source_accession=b['source_filing_identity']['accession'],status='PROVISIONAL_OTHER_FINANCING_AND_CLAIM_REVIEW_REMAINS',evidence_file='financing-component-reconciliations.json'))
with (OUT/'funding-candidates.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(candidates[0]));w.writeheader();w.writerows(candidates)
print('Saved',len(bridges),'exact component reconciliations and',len(candidates),'provisional funding candidates')
