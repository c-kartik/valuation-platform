"""Offline extraction from pinned retained SEC bodies; no repository mutations."""
from pathlib import Path
from decimal import Decimal
from collections import defaultdict
import base64,gzip,hashlib,json,re,sys,io,xml.etree.ElementTree as ET
ROOT=Path('/Users/kc/Projects/valuation-platform');OUT=Path(__file__).resolve().parent;OLD=OUT.parent/'fcfe-feasibility-audit-2026-11-02'
sys.path.insert(0,str(ROOT/'src'))
from valuation_platform.analyst import statement_delivery as documents
from valuation_platform.analyst.cfo_statement_reconciliation import displayed
A=json.loads((OLD/'retained-fact-audit.json').read_text())
D=json.loads((ROOT/'docs/reported-population-delivery-ledger.json').read_text())
needed={(p['source']['url'],p['source']['sha256']) for p in A['periods']};refs=defaultdict(set)
def walk(v,target):
 if isinstance(v,dict):
  if v.get('url','').endswith(('.htm','.html')) and v.get('body_reference'):target.add((v['url'],v['body_reference']))
  for x in v.values():walk(x,target)
 elif isinstance(v,list):
  for x in v:walk(x,target)
for r in D['rows']:walk(r,refs[r['identity']['fields']['accession']])
for rr in refs.values():needed.update(rr)
store={}
for path in sorted((ROOT/'docs/evidence').glob('*.json'))+sorted((ROOT/'tests/fixtures').glob('capex*json')):
 doc=json.loads(path.read_bytes()); entries=doc if isinstance(doc,list) else doc.get('artifacts',[])
 if not isinstance(entries,list):continue
 for i,a in enumerate(entries):
  key=(a.get('source_url'),a.get('sha256'))
  if key not in needed or key in store:continue
  enc=a.get('response_body_gzip_base64') or a.get('body_gzip_base64')
  if not enc:continue
  assert a.get('representation')=='sec_response_body_bytes' and a.get('digest_type')=='sha256_sec_response_body_bytes'
  body=gzip.decompress(base64.b64decode(''.join(enc) if isinstance(enc,list) else enc,validate=True))
  assert hashlib.sha256(body).hexdigest()==key[1]
  store[key]=dict(body=body,url=key[0],sha256=key[1],retained_path=str(path.relative_to(ROOT)),locator=f'/artifacts/{i}')
XI='{http://www.xbrl.org/2003/instance}';XDI='{http://xbrl.org/2006/xbrldi}'
MATCH=re.compile(r'Interest|IncomeTaxExpenseBenefit|IncomeLossFromContinuingOperationsBeforeIncomeTax|IncomeLossFromContinuingOperationsBeforeIncomeTaxes|ProfitLoss|NetIncomeLoss|NetCashProvidedByUsedIn|PaymentsToAcquire|ProceedsFromSaleOfProperty|PaymentsForProceedsFrom|ProceedsFrom.*(?:Debt|Borrow|CommercialPaper|Credit|Loans|Notes|Overdraft|Financ)|Repayments?Of.*(?:Debt|Borrow|CommercialPaper|Credit|Loans|Notes)|PrincipalPayments|FinancedProperty|CapitalExpend|ProceedsFromIssuance|Overdraft|DebtRepay|DebtIssu|ShortTermFinancing',re.I)
def instance(p):
 rec=store[(p['source']['url'],p['source']['sha256'])];body=rec['body'];root=ET.fromstring(body)
 ns={pre:u for _,(pre,u) in ET.iterparse(io.BytesIO(body),events=['start-ns'])}
 contexts={}
 for c in root.findall(XI+'context'):
  e=c.find(XI+'entity/'+XI+'identifier');period=c.find(XI+'period')
  if e is None or period is None:continue
  if e.get('scheme')!='http://www.sec.gov/CIK' or int(e.text)!=p['identity']['cik']:continue
  if (period.findtext(XI+'startDate'),period.findtext(XI+'endDate'))!=(p['identity']['annual_start'],p['identity']['annual_end']):continue
  dims=[dict(dimension=x.get('dimension'),member=x.text) for x in c.findall('.//'+XDI+'explicitMember')]
  dims += [dict(dimension=x.get('dimension'),typed=ET.tostring(x,encoding='unicode')) for x in c.findall('.//'+XDI+'typedMember')]
  contexts[c.get('id')]=dims
 units=set()
 for u in root.findall(XI+'unit'):
  mm=u.findall(XI+'measure')
  if len(mm)==1:
   pre,_,local=(mm[0].text or '').partition(':')
   if ns.get(pre)=='http://www.xbrl.org/2003/iso4217' and local=='USD':units.add(u.get('id'))
 facts=[]
 for ordinal,n in enumerate(root):
  if n.get('contextRef') not in contexts or n.get('unitRef') not in units:continue
  if n.get('{http://www.w3.org/2001/XMLSchema-instance}nil') in ('true','1'):continue
  con=n.tag.split('}')[-1]
  if not MATCH.search(con):continue
  try:v=Decimal(n.text)
  except:continue
  if not v.is_finite():continue
  facts.append(dict(concept=con,namespace=n.tag[1:].split('}')[0],value_usd=str(v),context_id=n.get('contextRef'),ordinal=ordinal,precision=n.get('decimals'),dimensions=contexts[n.get('contextRef')]))
 return dict(source={k:v for k,v in rec.items() if k!='body'},facts=facts)

def primary(p,record,companion=None):
 ns,contexts,units=documents.primary_bindings(record);contextsource=None
 if not contexts and companion:
  ns,contexts,units=documents.primary_bindings(companion);contextsource={k:v for k,v in companion.items() if k!='body'}
 eligible={}
 for cid,raw in contexts.items():
  s=re.search(r'<xbrli:startDate>([^<]+)',raw);e=re.search(r'<xbrli:endDate>([^<]+)',raw);ci=re.search(r'<xbrli:identifier[^>]*>([^<]+)',raw)
  if s and e and ci and (s[1],e[1],int(ci[1]))==(p['identity']['annual_start'],p['identity']['annual_end'],p['identity']['cik']):
   eligible[cid]=re.findall(r'<xbrldi:explicitMember[^>]*dimension="([^"]+)"[^>]*>([^<]+)',raw)
 usd=set()
 for uid,raw in units.items():
  mm=re.findall(r'<xbrli:measure>([^<]+)',raw)
  if 'divide' not in raw and len(mm)==1 and ns.get(mm[0].split(':')[0])=='http://www.xbrl.org/2003/iso4217' and mm[0].split(':')[-1]=='USD':usd.add(uid)
 tables=[]
 for ti,table in enumerate(documents.parse(record,improved=True)):
  rows=[];has=False
  for ri,row in enumerate(table):
   facts=[]
   for ci,cell in enumerate(row):
    for f in cell['facts']:
     attrs=f['attrs'];name=attrs.get('name','')
     if attrs.get('contextref') not in eligible or attrs.get('unitref') not in usd:continue
     try:v=displayed(cell['text'],Decimal(0))*Decimal(10)**int(attrs.get('scale','0'))
     except:continue
     if MATCH.search(name):has=True
     facts.append(dict(concept=name,context_id=attrs.get('contextref'),displayed_value_usd=str(v),raw_display=cell['text'],scale=attrs.get('scale'),cell=ci,inline_sign=attrs.get('sign'),dimensions=eligible[attrs.get('contextref')],xml_id=attrs.get('id')))
   caption=next((c['text'].strip() for c in row if c['text'].strip()),'');text=' '.join(c['text'] for c in row).strip()
   rows.append(dict(row=ri,caption=caption,text=text,facts=facts))
  if has:tables.append(dict(table=ti,rows=rows))
 return dict(source={k:v for k,v in record.items() if k!='body'},context_source=contextsource,tables=tables)

if __name__=='__main__':
 periods=[]
 for i,p in enumerate(A['periods']):
  out=dict(ticker=p['ticker'],identity=p['identity'],instance=instance(p),primary=[])
  records=[store[k] for k in sorted(refs[p['identity']['accession']]) if k in store]
  comps=[r for r in records if documents.primary_bindings(r)[1]]
  for rec in records:out['primary'].append(primary(p,rec,comps[0] if len(comps)==1 else None))
  periods.append(out)
  if (i+1)%10==0:print('Verified and parsed',i+1,flush=True)
 (OUT/'evidence.json').write_text(json.dumps(dict(scope='Retained selected annuals, exact USD annual contexts; dimensional facts kept separate; no missing-to-zero inference',periods=periods),indent=2)+'\n')
 print('Saved',len(periods),'selected periods',flush=True)
