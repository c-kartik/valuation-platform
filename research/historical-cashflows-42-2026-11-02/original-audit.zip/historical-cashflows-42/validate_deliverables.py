"""Independent CSV/JSON/XLSX checks. Read-only except the validation report."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
from decimal import Decimal
from html.parser import HTMLParser
import json,csv,hashlib,re,subprocess,zipfile,xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/kc/Projects/valuation-platform')
D=json.loads((OUT/'calculations.json').read_text());R=json.loads((OUT/'review-data.json').read_text())
checks=[]
def check(condition,label):
 assert condition,label
 checks.append(label)
check(len(D['periods'])==210 and len(D['companies'])==42,'210 requested slots and 42 issuers')
by=Counter(p['ticker'] for p in D['periods']);check(len(by)==42 and set(by.values())=={5},'Five requested slots for every issuer')
check(len({p['period_key'] for p in D['periods']})==210,'Unique issuer-period keys')
check(sum(p['record_type']=='RETAINED_FISCAL_PERIOD' for p in D['periods'])==203,'203 source-supported fiscal periods')
missing=[p for p in D['periods'] if p['record_type']=='MISSING_ANNUAL_SLOT'];check(len(missing)==7 and all(p['identity'] is None and p['fiscal_year'] is None and p['fcff'] is None and p['fcfe'] is None for p in missing),'Seven missing slots have no invented dates or values')
for m in ['fcff','fcfe']:
 counts=dict(Counter(p[m+'_status'].split('_')[0] for p in D['periods']))
 check(counts==D['metadata']['status_counts'][m]==R['metadata']['status_counts'][m],m+' status counts agree across final JSON files')
 for p in D['periods']:
  status=p[m+'_status'];issues=[i for i in p['issues'] if m.upper() in i['affects'] and i['severity'] in ['REVIEW','BLOCKER']]
  if status.startswith('SUPPORTED'):assert p[m] is not None and not issues
  elif status.startswith('PROVISIONAL'):assert p[m] is not None and issues
  else:assert p[m] is None and issues
 checks.append(m+' review readiness is consistent with every period’s flags')
rows=list(csv.DictReader((OUT/'financial-results.csv').open()));check(len(rows)==210,'CSV has 210 rows')
idx={p['period_key']:p for p in D['periods']}
for row in rows:
 p=idx[row['period_key']]
 for k in ['fcff','fcfe','expanded_fcff','expanded_fcfe']:
  if p[k] is None:assert row[k+'_usd']==''
  else:
   assert Decimal(row[k+'_usd'])==Decimal(p[k]['decimal_usd'])
   rational=Fraction(int(p[k]['numerator']),int(p[k]['denominator']))
   assert abs(Fraction(row[k+'_usd'])-rational)<Fraction(1,10**30)
checks.append('CSV numbers match exact JSON calculations, with no missing-to-zero conversion')
flags=list(csv.DictReader((OUT/'flags.csv').open()));check(len(flags)==len(R['flags'])==sum(len(p['issues']) for p in D['periods']),'All period flags are saved in CSV and both review structures')
check(len(list(csv.DictReader((OUT/'company-summary.csv').open())))==42,'Company summary includes the full universe')
check(len(list(csv.DictReader((OUT/'source-index.csv').open())))==len(R['sources']),'Source index row count matches review data')
check(len(list(csv.DictReader((OUT/'financing-schedule.csv').open())))==len(R['financing']),'Financing schedule row count matches review data')
validation=json.loads((OUT/'source-validation.json').read_text());check(not validation['errors'],'Independent raw/visible-cell replay has no numerical, context or unit errors')
check(validation['checks']['fcff_independent_fraction_checks']==195 and validation['checks']['fcfe_independent_fraction_checks']==201,'195 FCFF and 201 FCFE exact independent calculations')
check(validation['checks']['prior_pilot_fcff_matches']==13 and validation['checks']['prior_pilot_missing_periods_preserved']==2,'All 13 existing pilot values reproduce and two original unavailable years remain unavailable')
alt=json.loads((OUT/'later-vintage-validation.json').read_text());check(not alt['errors'] and alt['checks']['fcff_independent_fraction_checks']==10,'All ten later-source rebuilds have independent source/math validation')
fv=json.loads((OUT/'financing-comparative-validation.json').read_text());check(not fv['errors'] and fv['checks']['net_funding_schedule_checks']==21,'All 21 supplemental financing schedules have independent source and arithmetic validation')
bridges=json.loads((OUT/'financing-component-reconciliations.json').read_text())['bridges']
for bridge in bridges:
 left=sum((Fraction(t['row']['value_usd']) for t in bridge['left_terms']),Fraction(0));right=sum((Fraction(t['row']['value_usd']) for t in bridge['right_terms']),Fraction(0));assert left==right and Fraction(bridge['difference_usd'])==0
check(len(bridges)==5,'All five financing component reconciliations tie with no residual plug')
funding_candidates=list(csv.DictReader((OUT/'funding-candidates.csv').open()));check(len(funding_candidates)==2 and all(r['status'].startswith('PROVISIONAL') for r in funding_candidates),'Two improved-disaggregation funding candidates remain explicitly provisional')

# Financial semantic controls beyond an arithmetic tie.
pp=[p for p in D['periods'] if p['record_type']=='RETAINED_FISCAL_PERIOD']
for p in pp:
 if p['ticker']=='GOOGL' and p['fiscal_year'] in [2024,2025]:assert not any(r.get('classification')=='LEASE_NOTE_PRINCIPAL_COMPONENT' for r in p['financing']['rows'])
 if p['ticker']=='SNDK':assert all(not r['included_in_net_borrowing'] for r in p['financing']['rows'] if 'due from' in r['caption'].lower())
 if p['ticker']=='TSLA':assert not any(a['action']=='FIXED_ASSET_DISPOSAL_RECEIPT' for a in p['identified_expanded_investment']['adjustments'])
 if p['ticker']=='AVGO' and p['fiscal_year'] in [2021,2022]:assert p['inputs']['preferred_cash_dividends']['value_usd']=='299000000'
 if p['ticker']=='PLTR' and p['fiscal_year'] in [2021,2022]:assert all(not r['included_in_net_borrowing'] for r in p['financing']['rows'] if 'exercise' in r['caption'].lower())
 if p['ticker']=='MU' and p['fiscal_year']==2026:assert all(not r['included_in_net_borrowing'] for r in p['financing']['rows'] if r['classification']=='CUSTOMER_FUNDING_REVIEW')
 if p['ticker']=='LIN':
  a=p['inputs']['interest_expense'];assert Fraction(a['value_usd'])==Fraction(a['independent_reconstruction']['value_usd'])
checks.append('Known lease, preferred-dividend, crypto/net-capex, parent-note, customer-advance and tag/caption exceptions remain correctly classified')

# Frozen-bank fingerprints, including dates of fiscal contexts, remain intact.
old=json.loads((OUT.parent/'fcfe-feasibility-audit-2026-11-02/retained-fact-audit.json').read_text())
for src in old['sources']:assert hashlib.sha256((ROOT/src['path']).read_bytes()).hexdigest()==src['sha256'],src['path']
checks.append('Frozen-bank ledger and checkpoint fingerprints are unchanged')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
check(head==D['metadata']['repository_commit'] and status=='','Authoritative repository commit is unchanged and its working tree is clean')

# Read the exported workbook without using a second authoring library.
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
with zipfile.ZipFile(OUT/'historical-cashflows.xlsx') as z:
 assert z.testzip() is None
 wb=ET.fromstring(z.read('xl/workbook.xml'));sheets=wb.findall('s:sheets/s:sheet',NS)
 check([s.get('name') for s in sheets]==['Summary','Cashflows','Financing','Flags','Sources','Checks','Methodology'],'Exported workbook has all seven intended sheets')
 strings=[]
 if 'xl/sharedStrings.xml' in z.namelist():
  strings=[''.join(si.itertext()) for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
 def sheet_values(n):
  tree=ET.fromstring(z.read('xl/worksheets/sheet'+str(n)+'.xml'));values={}
  for cell in tree.findall('.//s:c',NS):
   v=cell.find('s:v',NS);text=None if v is None else v.text;kind=cell.get('t')
   if kind=='s':value=strings[int(text)]
   elif kind=='inlineStr':value=''.join(cell.find('s:is',NS).itertext())
   elif kind=='e':raise AssertionError('Native XLSX formula error '+str(text))
   elif kind in ['str','b']:value=text
   else:value=None if text in [None,''] else float(text)
   values[cell.get('r')]=value
  return tree,values
 tree,cv=sheet_values(2)
 for i,row in enumerate(R['results'],start=7):
  for col,key in [('N','fcff_usd'),('O','fcfe_usd'),('Q','expanded_fcff_usd'),('R','expanded_fcfe_usd')]:
   expected=None if row[key] is None else float(row[key])/1e6;actual=cv.get(col+str(i))
   if expected is None:assert actual in [None,'']
   else:assert isinstance(actual,(int,float)) and abs(actual-expected)<=1e-8,(row['period_key'],col,actual,expected)
 check(True,'All 840 exported cached cash-flow result cells match the final JSON within USD 0.01')
 _,sv=sheet_values(1)
 for i,c in enumerate(R['companies'],start=7):
  assert sv['C'+str(i)]==c['retained_periods']
  for col,key in [('D','fcff_supported'),('E','fcff_provisional'),('F','fcff_unavailable'),('G','fcfe_supported'),('H','fcfe_provisional'),('I','fcfe_unavailable')]:assert sv[col+str(i)]==c[key]
 check(True,'Every exported issuer coverage count matches the final dataset')
 native_tables=[n for n in z.namelist() if re.fullmatch('xl/tables/table[0-9]+.xml',n)]
 check(len(native_tables)==7,'Seven native Excel filter tables are present')
 for n in range(1,8):
  tree,_=sheet_values(n);pane=tree.find('s:sheetViews/s:sheetView/s:pane',NS);assert pane is not None and pane.get('ySplit')=='6'
 check(True,'Every workbook sheet preserves its frozen header rows')
 check(not any('externalLink' in n or 'vbaProject' in n for n in z.namelist()),'Workbook has no external workbook dependencies or macros')
wv=json.loads((OUT/'workbook-validation.json').read_text());check(not wv['failures'] and wv['sourcePerturbation']['restored'],'Workbook source dependency perturbation passed and was restored')
rv=json.loads((OUT/'report-validation.json').read_text());check(not rv['errors'] and rv['period_details_checked']==210,'Offline report behavior checks cover all 210 requested slots')

class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[];self.src=[]
 def handle_starttag(self,tag,attrs):
  aa=dict(attrs)
  if aa.get('id'):self.ids.append(aa['id'])
  if tag=='a' and aa.get('href'):self.links.append(aa['href'])
  if aa.get('src'):self.src.append(aa['src'])
parser=Links();text=(OUT/'report.html').read_text();parser.feed(text)
check(len(parser.ids)==len(set(parser.ids)),'Static report IDs are unique')
for href in parser.links:
 if not href.startswith(('https://','http://','#')):assert (OUT/href).exists(),href
check(not parser.src,'Report loads no external scripts, images or dependencies')
check(True,'Every static local report download/reference exists')
result=dict(scope='Delivery consistency checks; economic review flags remain open.',checks=checks,errors=[],repository_commit=head,counts=D['metadata']['status_counts'],numeric_fcff=195,numeric_fcfe=201,requested_slots=210,reported_periods=203,missing_annual_slots=7,raw_source_checks=validation['checks'],workbook=wv,report=rv)
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('Passed',len(checks),'delivery checks')
