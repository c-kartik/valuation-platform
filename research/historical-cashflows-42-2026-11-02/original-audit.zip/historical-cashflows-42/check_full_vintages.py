"""Rebuild all operands from one later retained filing, not one revised cell."""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import json,re,csv,xml.etree.ElementTree as ET
import extract_evidence as x
import calculate_cashflows as c
OUT=c.OUT;x.MATCH=re.compile('.*')
original=json.loads((OUT/'calculations-draft.json').read_text())['periods']
diffs=c.VINTAGES['differences']
targets={(r['ticker'],r['target_identity']['annual_end']) for r in diffs if r['classification']=='LATER_COMPARATIVE_AMOUNT_CHANGE'}
records=[];comparisons=[];new_evidence=[]
for t,end in sorted(targets):
 old=next(p for p in original if p['ticker']==t and p['identity']['annual_end']==end)
 candidates=sorted([p for p in c.E['periods'] if p['ticker']==t and p['identity']['annual_end']>end and p['history_origin']=='SELECTED_ANNUAL'],key=lambda p:p['identity']['annual_end'],reverse=True)
 selected=None
 for later in candidates:
  pp=dict(ticker=t,fiscal_year=old['fiscal_year'],identity=old['identity'],source=later['instance']['source'],source_filing_identity=later['source_filing_identity'],history_origin='SELECTED_ANNUAL')
  raw=x.instance(pp)
  if not any(f['concept'].startswith('NetCashProvidedByUsedInOperatingActivities') and not f['dimensions'] for f in raw['facts']):continue
  pp['instance']=raw;pp['primary']=[]
  for doc in later['primary']:
   src=doc['source'];rec=x.store[(src['url'],src['sha256'])];comp=doc.get('context_source');comp=x.store[(comp['url'],comp['sha256'])] if comp else None
   pp['primary'].append(x.primary(pp,rec,comp))
  selected=pp;break
 if selected is None:
  records.append(dict(ticker=t,annual_end=end,status='NO_LATER_COMPLETE_SOURCE_CANDIDATE'));continue
 result=c.calculate(selected)
 result['issues']=[i for i in result['issues'] if i['code']!='LATER_COMPARATIVE_AMOUNTS_DIFFER']
 result['issues'].append(c.issue('SUPPLEMENTAL_LATER_SOURCE_REBUILD','REVIEW',['FCFF','FCFE'],'All selected operands are rebuilt from the same later retained filing for comparison. These results are supplemental and do not replace the original as-filed series.','Reconcile changed captions/business scope before accepting a chosen comparative vintage.'))
 if t=='JNJ':result['issues'].append(c.issue('CONTINUING_PROFIT_CONSOLIDATED_CASH_COMPARATIVE_SCOPE','REVIEW',['FCFF','FCFE'],'Later p&l comparatives are recast for continuing operations; cash-flow comparatives require a corresponding discontinued-operations bridge.','Do not combine Kenvue-excluded profit/interest/taxes with unbridged consolidated cash.'))
 result['fcff_status']='UNAVAILABLE' if result['fcff'] is None else 'PROVISIONAL_REVIEW_REQUIRED';result['fcfe_status']='UNAVAILABLE' if result['fcfe'] is None else 'PROVISIONAL_REVIEW_REQUIRED'
 row=dict(ticker=t,fiscal_year=old['fiscal_year'],annual_end=end,original_accession=old['source_filing_identity']['accession'],later_source_accession=selected['source_filing_identity']['accession'],later_filing_end=selected['source_filing_identity']['annual_end'])
 for field in ['cfo','cash_capex','interest_expense','tax_provision','pretax_income','net_borrowing']:
  for prefix,p in [('original',old),('later',result)]:row[prefix+'_'+field+'_usd']=None if p['inputs'][field] is None else p['inputs'][field]['value_usd']
 for field in ['fcff','fcfe','expanded_fcff','expanded_fcfe']:
  for prefix,p in [('original',old),('later',result)]:row[prefix+'_'+field+'_usd']=None if p[field] is None else p[field]['decimal_usd']
  row[field+'_delta_usd']=None if old[field] is None or result[field] is None else c.dec(Fraction(int(result[field]['numerator']),int(result[field]['denominator']))-Fraction(int(old[field]['numerator']),int(old[field]['denominator'])))
 records.append(result);comparisons.append(row);new_evidence.append(selected)
 print(t,old['fiscal_year'],'source',selected['source_filing_identity']['annual_end'],'FCFE delta',row['fcfe_delta_usd'],'expanded FF delta',row['expanded_fcff_delta_usd'],flush=True)
(OUT/'later-vintage-evidence.json').write_text(json.dumps(dict(periods=new_evidence),indent=2)+'\n')
(OUT/'later-vintage-calculations.json').write_text(json.dumps(dict(scope='Supplemental full-source comparative rebuild only; original selected series is unchanged; all later-vintage calculations require review.',periods=records,comparison=comparisons),indent=2)+'\n')
with (OUT/'later-vintage-comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
