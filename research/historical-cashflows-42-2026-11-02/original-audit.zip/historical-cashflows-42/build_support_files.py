"""Review worklists, retained-bank inventory and prose evidence; no approvals."""
from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import json,csv,re,hashlib
from filing_text import loadtext
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/kc/Projects/valuation-platform')
D=json.loads((OUT/'calculations.json').read_text())
R=json.loads((OUT/'review-data.json').read_text())
groups=defaultdict(list)
for f in R['flags']:groups[(f['code'],f['severity'],f['affects'])].append(f)
rows=[]
for (code,severity,affects),ff in sorted(groups.items(),key=lambda k:({'BLOCKER':0,'REVIEW':1,'NOTE':2}[k[0][1]],k[0][0])):
 rows.append(dict(issue=code.replace('_',' ').capitalize(),code=code,severity=severity,affects=affects,company_count=len({f['ticker'] for f in ff}),company_year_count=len({f['period_key'] for f in ff}),company_years='; '.join(sorted({f['ticker']+' '+('FY'+str(f['fiscal_year']) if f['fiscal_year'] else f['period_key'].split('|')[1]) for f in ff})),next_step=ff[0]['remedy']))
with (OUT/'roadblock-summary.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
work=[]
for p in D['periods']:
 financing=p.get('financing',{});face=financing.get('rows',[]);issues=p['issues'];codes={i['code'] for i in issues}
 other=sum((Decimal(r['value_usd']) for r in face if r['classification']=='OTHER_FINANCING_EXCLUDED'),Decimal(0))
 mixed=sum((abs(Decimal(r['value_usd'])) for r in face if r['classification'] in ['MIXED_DEBT_OTHER_FINANCING','MIXED_DEBT_DERIVATIVE_SETTLEMENT']),Decimal(0))
 lease=financing.get('disclosed_lease_principal')
 cap=p.get('inputs',{}).get('cash_capex');expanded=p.get('identified_expanded_investment')
 review=[i for i in issues if i['severity'] in ['REVIEW','BLOCKER']]
 work.append(dict(period_key=p['period_key'],ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=None if not p['identity'] else p['identity']['annual_end'],fcff_status=p['fcff_status'],fcfe_status=p['fcfe_status'],nonzero_other_financing_net_usd=str(other) if any(r['classification']=='OTHER_FINANCING_EXCLUDED' for r in face) else None,mixed_debt_other_gross_cash_usd=str(mixed) if any(r['classification'] in ['MIXED_DEBT_OTHER_FINANCING','MIXED_DEBT_DERIVATIVE_SETTLEMENT'] for r in face) else None,separately_disclosed_lease_principal_usd=None if not lease else lease['value_usd'],expanded_minus_baseline_investment_usd=None if not cap or not expanded else str(Decimal(expanded['value_usd'])-Decimal(cap['value_usd'])),review_codes='; '.join(sorted({i['code'] for i in review})),remedies=' | '.join(dict.fromkeys(i['remedy'] for i in review))))
with (OUT/'review-worklist.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(work[0]));w.writeheader();w.writerows(work)
interest=[]
for p in D['periods']:
 if not p['identity']:continue
 selected=p['inputs'].get('interest_expense');cash=p.get('reported_cash_interest_for_basis_review')
 interest.append(dict(ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=p['identity']['annual_end'],selected_interest_expense_usd=None if not selected else selected['value_usd'],reported_cash_interest_usd=None if not cash else cash['value_usd'],cash_interest_caption='' if not cash else '; '.join(sorted({f['caption'] for f in cash['primary']})),cash_minus_selected_expense_usd=None if not selected or not cash else str(Decimal(cash['value_usd'])-Decimal(selected['value_usd'])),comparison_scope='Diagnostic only: cash timing, capitalized interest, tax-liability interest and noncash debt costs can differ. A difference is not automatically an error; cash interest is not substituted into the primary FCFF formula.',fcff_status=p['fcff_status']))
with (OUT/'interest-diagnostics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(interest[0]));w.writeheader();w.writerows(interest)

# All retained artifacts for the two short-history issuers and both Exxon identities.
inventory=defaultdict(list);scanned=[]
for path in sorted((ROOT/'docs/evidence').glob('*.json')):
 scanned.append(dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 doc=json.loads(path.read_bytes());aa=doc if isinstance(doc,list) else doc.get('artifacts',[])
 if not isinstance(aa,list):continue
 for i,a in enumerate(aa):
  url=a.get('source_url','')
  if any('/data/'+str(c)+'/' in url for c in [1996810,2023554,34088,2115436]):inventory[url].append(dict(retained_path=str(path.relative_to(ROOT)),locator=f'/artifacts/{i}',has_body=bool(a.get('response_body_gzip_base64') or a.get('body_gzip_base64')),sha256=a.get('sha256')))
(OUT/'missing-history-inventory.json').write_text(json.dumps(dict(scope='Retained docs/evidence body inventory only; absence here is not a claim that a filing does not exist publicly. No predecessor identity or fiscal dates are invented.',issuer_ciks={'GEV':1996810,'SNDK':2023554,'XOM_frozen_identity':2115436,'XOM_predecessor_candidate_not_accepted':34088},scanned_files=scanned,retained_urls=inventory),indent=2)+'\n')

# Store exact retained-prose excerpts for the accounting interpretations used.
E=json.loads((OUT/'evidence-final.json').read_text());notes=[]
queries=[('LLY','2023-12-31','Development milestone payments',850),('GOOGL','2025-12-31','Financing cash flows used for financing leases',550),('V','2022-09-30','Interest expense increased primarily due',750),('V','2023-09-30','Interest expense increased primarily due',650)]
for ticker,end,needle,radius in queries:
 text=re.sub(r'\s+',' ',loadtext(ticker,end));start=text.find(needle)
 assert start>=0,(ticker,end,needle)
 a=max(0,start-80);b=min(len(text),start+radius)
 period=next(p for p in E['periods'] if p['ticker']==ticker and p['identity']['annual_end']==end)
 notes.append(dict(ticker=ticker,source_filing_identity=period['source_filing_identity'],source_candidates=[d['source'] for d in period['primary']],normalized_text_rule='Collapse all whitespace to one space in the saved retained-primary text cache, which includes source headers.',start=a,end=b,excerpt=text[a:b]))
(OUT/'interpretation-evidence.json').write_text(json.dumps(dict(scope='Source excerpts supporting interpretation only; financial operands remain bound separately to their exact cells.',notes=notes),indent=2)+'\n')
print('Saved',len(rows),'issue groups;',len(work),'worklist periods;',len(inventory),'retained missing-history URLs;',len(notes),'interpretation excerpts')
