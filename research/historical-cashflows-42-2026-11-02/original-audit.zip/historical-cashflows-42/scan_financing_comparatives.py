"""Find later disaggregation of selected Other/mixed financing cash rows."""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import json,csv,io,re,xml.etree.ElementTree as ET
import extract_evidence as x
import calculate_cashflows as c
OUT=c.OUT;E=c.E;x.MATCH=re.compile('.*')
D=json.loads((OUT/'calculations-draft.json').read_text());targets=defaultdict(list)
CLASSES={'OTHER_FINANCING_EXCLUDED','MIXED_DEBT_OTHER_FINANCING','MIXED_LEASE_OTHER_FINANCING'}
for p in D['periods']:
 for r in p['financing']['rows']:
  if r['classification'] in CLASSES and Fraction(r['value_usd']) and r.get('instance_observations'):targets[p['ticker']].append((p,r))
XI=x.XI;found=[];same=0;missing=0
for source in [p for p in E['periods'] if p['history_origin']=='SELECTED_ANNUAL']:
 if source['ticker'] not in targets:continue
 rec=x.store[(source['instance']['source']['url'],source['instance']['source']['sha256'])];root=ET.fromstring(rec['body']);ns={p:u for _,(p,u) in ET.iterparse(io.BytesIO(rec['body']),events=['start-ns'])};units=set()
 for u in root.findall(XI+'unit'):
  measures=u.findall(XI+'measure')
  if len(measures)==1 and ns.get(measures[0].text.split(':')[0])=='http://www.xbrl.org/2003/iso4217' and measures[0].text.split(':')[-1]=='USD':units.add(u.get('id'))
 contexts={}
 for ctx in root.findall(XI+'context'):
  en=ctx.find(XI+'entity/'+XI+'identifier');per=ctx.find(XI+'period')
  if en is None or per is None or en.get('scheme')!='http://www.sec.gov/CIK' or int(en.text)!=source['identity']['cik']:continue
  if ctx.find('.//{http://xbrl.org/2006/xbrldi}explicitMember') is not None or ctx.find('.//{http://xbrl.org/2006/xbrldi}typedMember') is not None:continue
  contexts[ctx.get('id')]=(per.findtext(XI+'startDate'),per.findtext(XI+'endDate'))
 ff=defaultdict(list)
 for ordinal,node in enumerate(root):
  if node.get('contextRef') not in contexts or node.get('unitRef') not in units or node.get('{http://www.w3.org/2001/XMLSchema-instance}nil') in ['1','true']:continue
  try:Fraction(node.text)
  except:continue
  ff[(contexts[node.get('contextRef')],node.tag.split('}')[-1])].append(dict(value_usd=node.text,precision=node.get('decimals'),ordinal=ordinal,context_id=node.get('contextRef')))
 for target,row in targets[source['ticker']]:
  ident=target['identity']
  if source['identity']['cik']!=ident['cik']:continue
  if source['identity']['annual_end']<=ident['annual_end']:continue
  facts=ff.get(((ident['annual_start'],ident['annual_end']),row['primary_fact']['concept'].split(':')[-1]),[])
  if not facts:missing+=1;continue
  precision=lambda f:999 if str(f['precision']).upper()=='INF' else int(f['precision'])
  finest=max(precision(f) for f in facts);facts=[f for f in facts if precision(f)==finest];values={abs(Fraction(f['value_usd'])) for f in facts}
  if len(values)!=1:continue
  old=abs(Fraction(row['value_usd']));new=next(iter(values))
  if old==new:same+=1;continue
  found.append(dict(ticker=target['ticker'],fiscal_year=target['fiscal_year'],target_identity=ident,original_caption=row['caption'],original_signed_cash_usd=row['value_usd'],later_magnitude_usd=c.dec(new),later_source_filing=source['source_filing_identity'],later_facts=facts,source_period=source))
chosen={}
for r in found:
 k=(r['ticker'],r['target_identity']['annual_end'])
 if k not in chosen or chosen[k]['later_source_filing']['annual_end']<r['later_source_filing']['annual_end']:chosen[k]=r
records=[];evidence=[];comparison=[]
for (ticker,end),candidate in sorted(chosen.items()):
 old=next(p for p in D['periods'] if p['ticker']==ticker and p['identity']['annual_end']==end);source=candidate['source_period']
 pp=dict(ticker=ticker,fiscal_year=old['fiscal_year'],identity=old['identity'],source=source['instance']['source'],source_filing_identity=source['source_filing_identity'],history_origin='SELECTED_ANNUAL')
 pp['instance']=x.instance(pp);pp['primary']=[]
 for doc in source['primary']:
  ss=doc['source'];rec=x.store[(ss['url'],ss['sha256'])];co=doc.get('context_source');co=x.store[(co['url'],co['sha256'])] if co else None;pp['primary'].append(x.primary(pp,rec,co))
 newer=c.calculate(pp)
 newer['issues'].append(c.issue('SUPPLEMENTAL_FINANCING_COMPARATIVE_REBUILD','REVIEW',['FCFF','FCFE'],'Later source disaggregation is saved for research only. It is not merged into the original selected funding series.','Reconcile the original mixed cash row to later debt, lease and owner-cash captions before accepting a new chosen source vintage.'))
 for metric in ['fcff','fcfe']:newer[metric+'_status']='UNAVAILABLE' if newer[metric] is None else 'PROVISIONAL_REVIEW_REQUIRED'
 def excluded_other(p):return sum((Fraction(r['value_usd']) for r in p['financing']['rows'] if r['classification'] in CLASSES),Fraction(0))
 def funding(p):return None if p['inputs']['net_borrowing'] is None else Fraction(p['inputs']['net_borrowing']['value_usd'])
 a,b=funding(old),funding(newer)
 row=dict(ticker=ticker,fiscal_year=old['fiscal_year'],annual_end=end,original_accession=old['source_filing_identity']['accession'],later_source_accession=pp['source_filing_identity']['accession'],later_filing_end=pp['source_filing_identity']['annual_end'],original_other_or_mixed_cash_usd=c.dec(excluded_other(old)),later_other_or_mixed_cash_usd=c.dec(excluded_other(newer)),original_selected_net_funding_usd=None if a is None else c.dec(a),later_selected_net_funding_usd=None if b is None else c.dec(b),selected_funding_delta_usd=None if a is None or b is None else c.dec(b-a),scope='Later full-source rebuild; disaggregation changes are not automatically new cash or an approved source-vintage replacement.')
 records.append(newer);evidence.append(pp);comparison.append(row);print(ticker,old['fiscal_year'],'other',row['original_other_or_mixed_cash_usd'],'->',row['later_other_or_mixed_cash_usd'],'funding delta',row['selected_funding_delta_usd'],flush=True)
clean=[{k:v for k,v in r.items() if k!='source_period'} for r in found]
(OUT/'financing-comparative-calculations.json').write_text(json.dumps(dict(rule_version=c.RULE_VERSION,scope='Supplemental later disaggregation of financing cash; no original series or approval changes.',raw_same_amount_comparisons=same,raw_missing_same_concept=missing,changed_raw_comparisons=clean,periods=records,comparison=comparison),indent=2)+'\n')
(OUT/'financing-comparative-evidence.json').write_text(json.dumps(dict(periods=evidence),indent=2)+'\n')
if comparison:
 with (OUT/'financing-comparative-comparison.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(comparison[0]));w.writeheader();w.writerows(comparison)
print('Same',same,'changed raw',len(found),'rebuilt periods',len(records),'missing same-concept context',missing)
