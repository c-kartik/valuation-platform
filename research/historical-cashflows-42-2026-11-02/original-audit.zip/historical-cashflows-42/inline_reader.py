from html.parser import HTMLParser
from fractions import Fraction
import re
class Inline(HTMLParser):
 def __init__(self):super().__init__();self.facts=[];self.active=[];self.rows=[];self.all_rows=[];self.cells=[];self.hidden=0;self.tables=[];self.next_table=0;self.document_text=[]
 def handle_starttag(self,tag,attrs):
  aa=dict(attrs)
  if tag in ('ix:hidden','script','style'):self.hidden+=1
  if tag=='table':self.tables.append(self.next_table);self.next_table+=1
  if tag=='tr':
   row=dict(text=[],cells=[],table=self.tables[-1] if self.tables else None);self.rows.append(row);self.all_rows.append(row)
  if tag in ['td','th']:
   c=dict(text=[])
   if self.rows:self.rows[-1]['cells'].append(c)
   self.cells.append(c)
  if tag=='ix:nonfraction':self.active.append(dict(attrs=aa,text=[],cell=self.cells[-1] if self.cells else None,row=self.rows[-1] if self.rows else None,hidden=self.hidden))
 def handle_data(self,data):
  if not self.hidden:self.document_text.append(data)
  for f in self.active:f['text'].append(data)
  for r in self.rows:r['text'].append(data)
  for c in self.cells:c['text'].append(data)
 def handle_endtag(self,tag):
  if tag=='ix:nonfraction' and self.active:self.facts.append(self.active.pop())
  if tag in ['td','th'] and self.cells:self.cells.pop()
  if tag=='tr' and self.rows:self.rows.pop()
  if tag=='table' and self.tables:self.tables.pop()
  if tag in ('ix:hidden','script','style') and self.hidden:self.hidden-=1

def norm(s):return ' '.join(s.replace('\xa0',' ').split())
def number(s):
 s=norm(s).replace(',','').replace('−','-')
 if s in ['—','–','-','―','']:return Fraction(0)
 m=re.search(r'-?\d+(?:\.\d+)?',s)
 if not m:raise ValueError('No displayed number: '+s[:80])
 value=Fraction(m[0]);return -abs(value) if '(' in s and ')' in s else value

def primary_context_and_unit(body,attrs,target):
 """Independent visible-document metadata check, not a context-ID assumption."""
 text=body.decode()
 cid=re.escape(attrs['contextref']);uid=re.escape(attrs['unitref'])
 context=re.search(r'<(?:[\w-]+:)?context\b[^>]*\bid=["\']'+cid+r'["\'][^>]*>([\s\S]*?)</(?:[\w-]+:)?context>',text,re.I)
 unit=re.search(r'<(?:[\w-]+:)?unit\b[^>]*\bid=["\']'+uid+r'["\'][^>]*>([\s\S]*?)</(?:[\w-]+:)?unit>',text,re.I)
 if not context or not unit:return False
 s=re.search(r'<(?:[\w-]+:)?startDate>\s*([^<]+)',context[1],re.I);e=re.search(r'<(?:[\w-]+:)?endDate>\s*([^<]+)',context[1],re.I)
 entity=re.search(r'<(?:[\w-]+:)?identifier\b[^>]*scheme=["\']http://www.sec.gov/CIK["\'][^>]*>\s*(\d+)',context[1],re.I)
 mm=re.findall(r'<(?:[\w-]+:)?measure>\s*([\w-]+):([\w-]+)\s*</(?:[\w-]+:)?measure>',unit[1],re.I)
 if not s or not e or not entity or len(mm)!=1 or 'divide' in unit[1].lower():return False
 if (s[1].strip(),e[1].strip(),int(entity[1]))!=(target['annual_start'],target['annual_end'],target['cik']):return False
 namespace=re.search(r'xmlns:'+re.escape(mm[0][0])+r'=["\']([^"\']+)["\']',text)
 return mm[0][1]=='USD' and namespace is not None and namespace[1]=='http://www.xbrl.org/2003/iso4217'


def cell_display_text(actual):
 if not actual['cell']:return ''.join(actual['text'])
 text=''.join(actual['cell']['text'])
 if '(' in text and ')' not in text and actual['row']:
  cells=actual['row']['cells'];idx=next(i for i,c in enumerate(cells) if c is actual['cell'])
  for c in cells[idx+1:idx+3]:
   extra=norm(''.join(c['text']))
   if extra==')':text+=')';break
   if extra:break
 return text
