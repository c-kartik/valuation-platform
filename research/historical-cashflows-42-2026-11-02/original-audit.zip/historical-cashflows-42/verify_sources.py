"""Independent source replay with stdlib HTMLParser and exact rational arithmetic.

This verifies numerical/period/unit/visible-cell provenance. It does not turn an
unresolved economic classification into an approval or estimate.
"""
from pathlib import Path
from collections import defaultdict,Counter
from fractions import Fraction
from decimal import Decimal
from html.parser import HTMLParser
import hashlib,json,re,io,sys,xml.etree.ElementTree as ET
import extract_evidence as x
OUT=x.OUT;FINANCING_COMPARATIVES='--financing-comparatives' in sys.argv;ALTERNATE='--later-vintages' in sys.argv or FINANCING_COMPARATIVES
DATA_NAME='financing-comparative-calculations.json' if FINANCING_COMPARATIVES else 'later-vintage-calculations.json' if ALTERNATE else 'calculations-draft.json'
EVIDENCE_NAME='financing-comparative-evidence.json' if FINANCING_COMPARATIVES else 'later-vintage-evidence.json' if ALTERNATE else 'evidence-final.json'
DATA=json.loads((OUT/DATA_NAME).read_text());E=json.loads((OUT/EVIDENCE_NAME).read_text())
from inline_reader import Inline,norm,number,primary_context_and_unit,cell_display_text

points={};primary_groups=defaultdict(list);instance_groups=defaultdict(list)
def add(point,path):
 if not point:return
 if point.get('independent_reconstruction'):add(point['independent_reconstruction'],path+'/independent_reconstruction')
 if point.get('terms'):
  assert Fraction(point['value_usd'])==sum((Fraction(t['multiplier'])*Fraction(t['point']['value_usd']) for t in point['terms']),Fraction(0))
  for i,t in enumerate(point['terms']):add(t['point'],path+f'/terms/{i}')
  return
 if point.get('primary_only'):
  pp=point['primary_only'];key=('PRIMARY_ONLY',pp['source']['url'],pp['table'],pp['row'],pp['cell'])
 elif point.get('instance'):
  ii=point['instance'];key=(ii['source']['url'],point.get('concept'),point['value_usd'],tuple(f['ordinal'] for f in ii['observations']))
 else:return
 if key in points:points[key]['paths'].append(path);return
 item={'point':point,'paths':[path]};points[key]=item
 if point.get('instance'):instance_groups[(point['instance']['source']['url'],point['instance']['source']['sha256'])].append(item)
 for f in point.get('primary',[]):primary_groups[(f['source']['url'],f['source']['sha256'])].append((item,f))
 if point.get('primary_only'):primary_groups[(pp['source']['url'],pp['source']['sha256'])].append((item,{'primary_only':pp}))
for i,p in enumerate(DATA['periods']):
 for field,point in p['inputs'].items():add(point,f'/periods/{i}/inputs/{field}')
 for field,point in p['supporting_claims'].items():add(point,f'/periods/{i}/supporting_claims/{field}')
 if isinstance(p.get('financing'),dict):add(p['financing'].get('disclosed_lease_principal'),f'/periods/{i}/disclosed_lease_principal')
 for j,nc in enumerate(p.get('noncash_financing_addbacks',[])):add(nc,f'/periods/{i}/noncash_financing_addbacks/{j}')
 add(p.get('reported_cash_interest_for_basis_review'),f'/periods/{i}/reported_cash_interest_for_basis_review')
 if p['identified_expanded_investment']:
  for j,a in enumerate(p['identified_expanded_investment']['adjustments']):add(a['point'],f'/periods/{i}/investment_adjustment/{j}')
 for j,row in enumerate(p['financing']['rows'] if isinstance(p['financing'],dict) else []):
  if row.get('point'):add(row['point'],f'/periods/{i}/financing/{j}');continue
  if not row.get('instance_observations'):continue
  point=dict(value_usd=row['value_usd'],concept=row['primary_fact']['concept'].split(':')[-1],target_period={k:p['identity'][k] for k in ('cik','annual_start','annual_end')},instance=dict(source=row['instance_source'],observations=row['instance_observations']),primary=[dict(source=row['source'],caption=row['caption'],table=row['table'],row=row['row'],**row['primary_fact'])],role='cash')
  add(point,f'/periods/{i}/financing/{j}')

# Replay control operands too; a statement tie is not accepted merely because
# two values in a derived workpaper agree with each other.
CASH_CONTROLS={'periods':[]} if ALTERNATE else json.loads((OUT/'cash-statement-controls.json').read_text())
for i,p in enumerate(CASH_CONTROLS['periods']):
 for field,point in p['inputs'].items():add(point,f'/cash_statement_controls/{i}/{field}')

verified_sources=[];errors=[];checks=Counter();XI=x.XI
for key,items in instance_groups.items():
 rec=x.store[key];body=rec['body'];assert hashlib.sha256(body).hexdigest()==key[1]
 root=ET.fromstring(body);children=list(root);ns={p:u for _,(p,u) in ET.iterparse(io.BytesIO(body),events=['start-ns'])}
 contexts={c.get('id'):c for c in root.findall(XI+'context')};units={u.get('id'):u for u in root.findall(XI+'unit')}
 for item in items:
  point=item['point'];target=point['target_period']
  for obs in point['instance']['observations']:
   node=children[obs['ordinal']];ctx=contexts[node.get('contextRef')];entity=ctx.find(XI+'entity/'+XI+'identifier');per=ctx.find(XI+'period');mm=units[node.get('unitRef')].findall(XI+'measure')
   try:
    assert node.tag.split('}')[-1]==obs['concept']==point['concept']
    assert node.tag[1:].split('}')[0]==obs['namespace']
    assert node.get('contextRef')==obs['context_id']
    assert Fraction(node.text)==Fraction(obs['value_usd'])
    assert node.get('{http://www.w3.org/2001/XMLSchema-instance}nil') not in ['true','1']
    assert int(entity.text)==target['cik'] and entity.get('scheme')=='http://www.sec.gov/CIK'
    assert (per.findtext(XI+'startDate'),per.findtext(XI+'endDate'))==(target['annual_start'],target['annual_end'])
    assert len(mm)==1 and ns[mm[0].text.split(':')[0]]=='http://www.xbrl.org/2003/iso4217' and mm[0].text.split(':')[-1]=='USD'
    checks['instance_observations']+=1
   except Exception as e:errors.append(dict(path=item['paths'][0],reason='INSTANCE_'+type(e).__name__,source=key[0],concept=point['concept']))
 verified_sources.append(dict(url=key[0],sha256=key[1],kind='EXTRACTED_INSTANCE',retained_path=rec['retained_path'],locator=rec['locator']))

# Same-accession context wrappers are explicit in the retained delivery proof.
context_companions={}
for p in E['periods']:
 for d in p['primary']:
  if d.get('context_source'):context_companions[(d['source']['url'],d['source']['sha256'])]=d['context_source']
for no,(key,items) in enumerate(primary_groups.items()):
 rec=x.store[key];body=rec['body'];assert hashlib.sha256(body).hexdigest()==key[1]
 parser=Inline();parser.feed(body.decode());parser.close();ids=defaultdict(list);by_name_context=defaultdict(list)
 for f in parser.facts:
  if f['hidden']:continue
  if f['attrs'].get('id'):ids[f['attrs']['id']].append(f)
  by_name_context[(f['attrs'].get('name'),f['attrs'].get('contextref'))].append(f)
 namespaces=defaultdict(set);metadata_cache={}
 for m in re.finditer(r'xmlns:([A-Za-z0-9_-]+)=["\']([^"\']+)["\']',body.decode()):namespaces[m[1]].add(m[2])
 for item,pointfact in items:
  point=item['point']
  if pointfact.get('primary_only'):
   pp=pointfact['primary_only'];assert pp['caption']=='Interest expense' or pp['caption']=='Tax on interest expense'
   # Replay the complete source-bound, untampered table and explicit year column.
   source_pp=next(r for r in json.loads((OUT/'primary-only-pep-interest.json').read_text()) if r['source']==pp['source'] and r['table']==pp['table'])
   cell=source_pp['rows'][pp['row']]['cells'][pp['cell']]
   assert cell==pp['raw_display'] and number(cell)*10**pp['scale']==Fraction(point['value_usd'])
   assert source_pp['rows'][pp['header']['row']]['cells'][1]==str(point['source_filing_identity']['annual_end'][:4])
   assert norm(pp['document_unit_rule']['text']) in norm(' '.join(parser.document_text))
   native=[]
   for rr in parser.all_rows:
    cells=[norm(''.join(c['text'])) for c in rr['cells']]
    if not cells or cells[0]!=pp['caption']:continue
    numeric=[z for z in cells[1:] if re.search(r'\d',z)]
    if not numeric or number(numeric[0])*10**pp['scale']!=Fraction(point['value_usd']):continue
    headers=[norm(''.join(z['text'])) for z in parser.all_rows if z['table']==rr['table']][:3]
    if str(point['source_filing_identity']['annual_end'][:4]) not in ' '.join(headers):continue
    native.append(rr)
   assert native,'Untagged preferred/current ROIC amount absent from independently parsed table'
   checks['primary_only_untagged_operands']+=1;continue
  f=pointfact;candidates=ids.get(f.get('xml_id'),[]) if f.get('xml_id') else []
  if not candidates:candidates=by_name_context[(f['concept'],f['context_id'])]
  matches=[]
  for actual in candidates:
   a=actual['attrs']
   if a.get('name')!=f['concept'] or a.get('contextref')!=f['context_id']:continue
   try:
    v=number(''.join(actual['text']))*Fraction(10)**int(a.get('scale','0'))
    if abs(v)!=abs(Fraction(f['displayed_value_usd'])):continue
    if actual['row'] and norm(f['caption']) not in norm(''.join(actual['row']['text'])):continue
    if actual['cell']:
     signed=number(cell_display_text(actual))*Fraction(10)**int(a.get('scale','0'))
     if signed!=Fraction(f['displayed_value_usd']):continue
    if not point.get('instance'):continue
    expected_ns={o['namespace'] for o in point['instance']['observations']}
    prefix=a['name'].split(':')[0]
    actual_ns=namespaces.get(prefix,set())
    if not actual_ns and key in context_companions:
     cb=x.store[(context_companions[key]['url'],context_companions[key]['sha256'])]['body'].decode()
     actual_ns={m[1] for m in re.finditer(r'xmlns:'+re.escape(prefix)+r'=["\']([^"\']+)["\']',cb)}
    if expected_ns!=actual_ns:continue
    metadata_key=(a['contextref'],a['unitref'],tuple(point['target_period'].items()))
    if metadata_key not in metadata_cache:
     metadata_ok=primary_context_and_unit(body,a,point['target_period'])
     if not metadata_ok and key in context_companions:
      cb=x.store[(context_companions[key]['url'],context_companions[key]['sha256'])]['body']
      metadata_ok=primary_context_and_unit(cb,a,point['target_period'])
     metadata_cache[metadata_key]=metadata_ok
    metadata_ok=metadata_cache[metadata_key]
    if not metadata_ok:continue
    matches.append(actual)
   except Exception:continue
  if not matches:errors.append(dict(path=item['paths'][0],reason='VISIBLE_PRIMARY_CELL_OR_NAMESPACE_MISMATCH',source=key[0],concept=f['concept'],context=f['context_id'],xml_id=f.get('xml_id'),table=f.get('table'),row=f.get('row')))
  else:checks['visible_inline_cell_checks']+=1
 verified_sources.append(dict(url=key[0],sha256=key[1],kind='VISIBLE_PRIMARY_DOCUMENT',retained_path=rec['retained_path'],locator=rec['locator']))
 if (no+1)%40==0:print('Replayed primary documents',no+1,flush=True)

# Exact independent algebra, including actual preferred cash when disclosed.
for p in DATA['periods']:
 ii=p['inputs'];value=lambda k:None if ii[k] is None else Fraction(ii[k]['value_usd'])
 cfo,cap,interest,tax,pre,nb,pref=[value(k) for k in ['cfo','cash_capex','interest_expense','tax_provision','pretax_income','net_borrowing','preferred_cash_dividends']]
 if p['fcff']:
  expected=cfo-cap+interest*(1-tax/pre)
  assert expected==Fraction(int(p['fcff']['numerator']),int(p['fcff']['denominator']));checks['fcff_independent_fraction_checks']+=1
 if p['fcfe']:
  expected=cfo-cap+nb-(pref if pref is not None else 0)
  assert expected==Fraction(int(p['fcfe']['numerator']),int(p['fcfe']['denominator']));checks['fcfe_independent_fraction_checks']+=1
 if p['fcff'] and p['fcfe']:
  assert Fraction(int(p['fcfe']['numerator']),int(p['fcfe']['denominator']))-Fraction(int(p['fcff']['numerator']),int(p['fcff']['denominator']))==nb-interest*(1-tax/pre)-(pref if pref is not None else 0)
  checks['fcff_fcfe_identity_checks']+=1
 if p['identified_expanded_investment']:
  inv=p['identified_expanded_investment'];expected=cap-sum((Fraction(a['cash_flow_usd']) for a in inv['adjustments']),Fraction(0))
  assert expected==Fraction(inv['value_usd']);checks['expanded_investment_checks']+=1
 if p['financing'] and isinstance(p['financing'],dict):
  rows=p['financing']['rows'];calc=sum((Fraction(r['value_usd']) for r in rows if r['included_in_net_borrowing']),Fraction(0))
  if nb is not None:assert calc==nb;checks['net_funding_schedule_checks']+=1
  face=[r for r in rows if not r.get('not_added_to_financing_total')]
  total=[Fraction(r['value_usd']) for r in face if r['classification']=='FINANCING_TOTAL']
  comps=sum((Fraction(r['value_usd']) for r in face if r['classification']!='FINANCING_TOTAL'),Fraction(0))
  if len(total)==1:
   checks['financing_sections_reconciled']+=1
   checks['financing_sections_exactly_tied' if comps==total[0] else 'financing_sections_display_difference']+=1
for control in CASH_CONTROLS['periods']:
 ii=control['inputs'];status=control['status']
 amount=lambda k:Fraction(ii[k]['value_usd'])
 if status in ['EXACT_TIE','DISPLAY_OR_SCOPE_DIFFERENCE_REVIEW']:
  expected=sum((amount(k) for k in ['cfo','cfi','cff','fx']),Fraction(0))-amount('cash_change')
  assert expected==Fraction(control['difference_usd']);checks['whole_cash_statement_algebra_checks']+=1
 elif status=='EXACT_TIE_EXCLUDING_FX':
  assert sum((amount(k) for k in ['cfo','cfi','cff']),Fraction(0))==amount('cash_change_excluding_fx');checks['whole_cash_statement_excluding_fx_checks']+=1
 elif status=='THREE_REPORTED_SUBTOTALS_MATCH_CHANGE_NO_FX_OPERAND_USED':
  assert ii['fx'] is None and sum((amount(k) for k in ['cfo','cfi','cff']),Fraction(0))==amount('cash_change');checks['three_reported_subtotals_without_fx_operand_checks']+=1

# Prior independently accepted pilot mathematical control (not a new approval).
pilot={'companies':[]} if ALTERNATE else json.loads((x.ROOT/'docs/company-data-preparation/historical-fcff-filing-calculations.json').read_text())
for company in pilot['companies']:
 for old in company['periods']:
  p=next(p for p in DATA['periods'] if p['ticker']==company['ticker'] and p['identity']==old['identity'])
  if old['fcff']:
   a=old['fcff']['exact_fraction_usd'];b=p['fcff'];assert Fraction(int(a['numerator']),int(a['denominator']))==Fraction(int(b['numerator']),int(b['denominator']));checks['prior_pilot_fcff_matches']+=1
  else:assert p['fcff'] is None;checks['prior_pilot_missing_periods_preserved']+=1
expected_count=len(E['periods']) if FINANCING_COMPARATIVES else 10 if ALTERNATE else 203
assert len(DATA['periods'])==expected_count and len({(p['ticker'],p['identity']['annual_start'],p['identity']['annual_end']) for p in DATA['periods']})==expected_count
if not ALTERNATE:assert checks['prior_pilot_fcff_matches']==13 and checks['prior_pilot_missing_periods_preserved']==2
result=dict(scope='Independent numerical/period/unit/visible-cell replay, financial algebra and stated scope controls. Economic review flags are not cleared by these checks.',checks=dict(checks),distinct_operand_or_statement_points=len(points),verified_source_bodies=verified_sources,errors=errors)
OUTPUT_NAME='financing-comparative-validation.json' if FINANCING_COMPARATIVES else 'later-vintage-validation.json' if ALTERNATE else 'source-validation.json'
(OUT/OUTPUT_NAME).write_text(json.dumps(result,indent=2)+'\n')
print('CHECKS',dict(checks));print('ERRORS',len(errors));print(json.dumps(errors[:12],indent=2))
if errors:raise SystemExit(1)
