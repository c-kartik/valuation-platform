"""Package research outputs without changing application data or approvals."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
from datetime import datetime,timezone
import json,csv,html,hashlib
OUT=Path(__file__).resolve().parent
OLD=OUT.parent/'fcfe-feasibility-audit-2026-11-02'
D=json.loads((OUT/'calculations-draft.json').read_text())
OLD_D=json.loads((OLD/'retained-fact-audit.json').read_text())
CONTROLS=json.loads((OUT/'cash-statement-controls.json').read_text())
S=json.loads((OUT/'source-validation.json').read_text())
UNIVERSE_PATH=Path('/Users/kc/Projects/valuation-platform/docs/universe/sp500-top-50-2026-10-02.csv')
NAMES={r['project_ticker']:r['company_name'] for r in csv.DictReader(UNIVERSE_PATH.open())}
def key(p):return p['ticker']+'|'+p['identity']['annual_end']
ci={key(p):p for p in CONTROLS['periods']}
periods=D['periods'];tickers=sorted(c['ticker'] for c in OLD_D['companies'])
FC=json.loads((OUT/'financing-comparative-calculations.json').read_text()) if (OUT/'financing-comparative-calculations.json').exists() else {'comparison':[]}
fc_index={(r['ticker'],r['annual_end']):r for r in FC['comparison']}
for p in periods:
 p['period_key']=key(p);p['cash_statement_control']=ci[key(p)]
 control=ci[key(p)]
 if control['status']=='DISPLAY_OR_SCOPE_DIFFERENCE_REVIEW':
  p['issues'].append(dict(code='WHOLE_CASH_STATEMENT_DISPLAY_DIFFERENCE',severity='NOTE',affects=['FCFF','FCFE'],explanation=f"Reported cash-flow subtotals versus reported cash change differ by {control['difference_usd']} USD. No plug or zero fill is applied.",remedy='Review the saved source cells and their display precision. This diagnostic does not change individually reported CFO, investment, or debt amounts.'))
 elif control['status']=='NOT_CHECKED_MISSING_OR_NONCONSOLIDATED_SUBTOTAL':
  p['issues'].append(dict(code='WHOLE_STATEMENT_CONSOLIDATED_CONTROL_UNAVAILABLE',severity='NOTE',affects=['FCFF','FCFE'],explanation='A consolidated whole-statement identity is not tested because selected disclosures use a continuing-operations perimeter.',remedy='Reconcile continuing and discontinued cash-flow subtotals separately before claiming a consolidated whole-statement tie.'))
 p['record_type']='RETAINED_FISCAL_PERIOD'
 funding_comparison=fc_index.get((p['ticker'],p['identity']['annual_end']))
 if funding_comparison:
  p['financing_comparative_review']=funding_comparison
  delta=funding_comparison['selected_funding_delta_usd']
  severity='REVIEW' if delta is None or Decimal(delta)!=0 else 'NOTE'
  p['issues'].append(dict(code='LATER_FINANCING_PRESENTATION_DIFFERS',severity=severity,affects=['FCFE'],explanation=f"A later retained filing ({funding_comparison['later_source_accession']}) changes the Other/mixed financing presentation. Rebuilding selected net funding from that later presentation gives a difference of {delta} USD. This is not automatically new cash; an earlier explicit component can be hidden inside later Other cash.",remedy='Reconcile both complete cash schedules, including debt, lease, owner and supplier-financing components. Preserve earlier explicit repayments when later aggregated; incorporate newly explicit borrowing only with source containment. See the saved financing comparison and exact component reconciliations.',evidence_file='financing-comparative-calculations.json'))
  if p['fcfe'] is not None and severity=='REVIEW':p['fcfe_status']='PROVISIONAL_REVIEW_REQUIRED'
for ticker in tickers:
 missing=5-sum(p['ticker']==ticker for p in periods)
 for slot in range(1,missing+1):
  why=('The frozen issuer identity has no selected annual filing in the retained bank. No predecessor response body was found.' if ticker=='XOM' else 'Only four distinct fiscal periods can be recovered from retained annuals and comparative columns. Standalone history is shorter than the requested five slots.')
  fix=('Verify the official predecessor/successor identity and retrieve the missing annual source bodies, then normalize and reconcile their statements.' if ticker=='XOM' else 'Retrieve an earlier predecessor/carve-out annual statement with explicit dates and entity scope, or clearly retain a shorter public-company history.')
  periods.append(dict(ticker=ticker,fiscal_year=None,identity=None,period_key=f'{ticker}|MISSING_SLOT_{slot}',record_type='MISSING_ANNUAL_SLOT',history_origin='UNAVAILABLE',fcff=None,fcfe=None,fcff_status='UNAVAILABLE',fcfe_status='UNAVAILABLE',issues=[dict(code='MISSING_RETAINED_ANNUAL_SLOT',severity='BLOCKER',affects=['FCFF','FCFE'],explanation=why,remedy=fix)],inputs={},identified_expanded_investment=None,expanded_fcff=None,expanded_fcfe=None,source_instance=None))
periods.sort(key=lambda p:(p['ticker'],p['identity']['annual_end'] if p['identity'] else '9999'+p['period_key']))
summary=[];flags=[];financing=[];sources=[];results=[]
def usd(v):return None if v is None else v['decimal_usd']
def point_sources(p,field,v):
 if not v:return
 if v.get('independent_reconstruction'):point_sources(p,field+' / independent debt-note cross-check',v['independent_reconstruction'])
 if v.get('terms'):
  for i,t in enumerate(v['terms']):point_sources(p,field+f' / term {i+1} ({t["multiplier"]})',t['point'])
  return
 refs=v.get('primary',[])
 if v.get('primary_only'):refs=[v['primary_only']]
 if not refs:return
 f=refs[0];source=f['source'];inst=v.get('instance',{});obs=inst.get('observations',[])
 sources.append(dict(period_key=p['period_key'],ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=p['identity']['annual_end'],field=field,value_usd=v['value_usd'],concept=v.get('concept',''),caption=f.get('caption',''),evidence=v.get('evidence_depth','PRIMARY_ONLY'),primary_url=source['url'],primary_sha256=source['sha256'],table=f.get('table'),row=f.get('row'),cell=f.get('cell'),context=f.get('context_id',''),instance_url=inst.get('source',{}).get('url',''),instance_sha256=inst.get('source',{}).get('sha256',''),instance_ordinals=';'.join(str(x['ordinal']) for x in obs),retained_path=source['retained_path'],body_locator=source['locator']))
for p in periods:
 ident=p['identity'] or {}; inp=p['inputs']
 row=dict(period_key=p['period_key'],ticker=p['ticker'],company_name=NAMES.get(p['ticker'],p['ticker']),fiscal_year=p['fiscal_year'],annual_start=ident.get('annual_start'),annual_end=ident.get('annual_end'),record_type=p['record_type'],history_origin=p['history_origin'],fcff_status=p['fcff_status'],fcfe_status=p['fcfe_status'])
 for field in ['cfo','cash_capex','interest_expense','tax_provision','pretax_income','net_borrowing','preferred_cash_dividends']:
  v=inp.get(field);row[field+'_usd']=None if not v else v['value_usd'];point_sources(p,field,v)
 for field in ['cash_fcf','fcff','fcfe','expanded_fcff','expanded_fcfe']:
  row[field+'_usd']=usd(p.get(field))
 row['reported_etr']=p.get('reported_etr')
 ex=p.get('identified_expanded_investment');row['expanded_investment_usd']=None if not ex else ex['value_usd']
 row['source_primary_url']=';'.join(sorted({s['primary_url'] for s in sources if s['period_key']==p['period_key']}))
 row['accession']=ident.get('accession');row['flag_count']=len(p['issues']);results.append(row)
 for i,issue in enumerate(p['issues']):flags.append(dict(period_key=p['period_key'],ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=ident.get('annual_end'),severity=issue['severity'],affects=';'.join(issue['affects']),code=issue['code'],explanation=issue['explanation'],remedy=issue['remedy'],accession=ident.get('accession'),primary_url=row['source_primary_url'],evidence_file=issue.get('evidence_file','calculations.json')))
 for field,point in p.get('supporting_claims',{}).items():point_sources(p,field,point)
 point_sources(p,'disclosed lease principal / containment review',p.get('financing',{}).get('disclosed_lease_principal'))
 for j,nc in enumerate(p.get('noncash_financing_addbacks',[])):point_sources(p,f'noncash financing CFO addback / {j+1}',nc)
 point_sources(p,'reported cash interest / basis review only',p.get('reported_cash_interest_for_basis_review'))
 for a in (ex or {}).get('adjustments',[]):point_sources(p,'investment adjustment / '+a['action'],a['point'])
 for r in p.get('financing',{}).get('rows',[]):
  src=r.get('source') or ((r.get('point') or {}).get('primary') or [{}])[0].get('source',{})
  financing.append(dict(period_key=p['period_key'],ticker=p['ticker'],fiscal_year=p['fiscal_year'],annual_end=ident.get('annual_end'),caption=r['caption'],classification=r['classification'],signed_cash_usd=r['value_usd'],included_in_net_borrowing=r['included_in_net_borrowing'],primary_url=src.get('url',''),primary_sha256=src.get('sha256',''),table=r.get('table'),row=r.get('row'),concept=(r.get('primary_fact') or {}).get('concept',(r.get('point') or {}).get('concept',''))))
for t in tickers:
 pp=[p for p in periods if p['ticker']==t];rr=dict(ticker=t,company_name=NAMES.get(t,t),requested_slots=5,retained_periods=sum(p['record_type']=='RETAINED_FISCAL_PERIOD' for p in pp),fiscal_years=', '.join(str(p['fiscal_year']) for p in pp if p['identity']))
 for m in ['fcff','fcfe']:
  count=Counter(p[m+'_status'].split('_')[0] for p in pp)
  for s in ['SUPPORTED','PROVISIONAL','UNAVAILABLE']:rr[m+'_'+s.lower()]=count[s]
 rr['review_codes']='; '.join(sorted({i['code'] for p in pp for i in p['issues'] if i['severity'] in ['BLOCKER','REVIEW']}));summary.append(rr)
counts={m:dict(Counter(p[m+'_status'].split('_')[0] for p in periods)) for m in ['fcff','fcfe']}
meta=dict(title='Historical FCFF and FCFE — retained filings research',created_utc=datetime.now(timezone.utc).isoformat(),started_utc='2026-11-02T17:45:46Z',budget_end_utc='2026-11-02T19:45:46Z',universe=tickers,requested_slots=210,retained_selected_annuals=199,recovered_comparative_periods=4,research_periods=203,missing_annual_slots=7,status_counts=counts,rule_version=D['rule_version'],units='USD; display in USD millions in workbook and USD billions in report',repository='/Users/kc/Projects/valuation-platform',repository_commit='4555c7d7c894b3af6f50cce506229c2fd2a515d1',no_new_filings_retrieved=True,application_data_or_approvals_modified=False)
methodology=[
 ('Scope','Five most recent distinct annual fiscal periods supported by this frozen retained bank per issuer. Fiscal-year labels and fiscal dates come from filing contexts; this is not a common calendar-year panel or a guarantee that every latest filing has been retrieved.'),
 ('Cash FCF','Reported operating cash flow less the explicitly selected reported cash capital expenditure amount.'),
 ('FCFF baseline','CFO − cash capex + gross expensed interest × (1 − reported income-tax provision / reported pretax income). Reported ETR is a stated convention, not an observed marginal interest tax shield. Losses, tax benefits, extreme ETRs and source-scope issues remain flagged.'),
 ('Selected interest expense','Gross borrowing interest is selected where separately disclosed. PepsiCo’s ROIC interest line and Visa’s mixed interest line are retained only provisionally. Explicit noncash financing costs already added back within CFO require reconciliation to interest expense; no unreported component or cash-tax shield is invented.'),
 ('FCFE baseline','CFO − cash capex + selected non-overlapping net debt cash funding − separately reported preferred cash dividends when bound. Ordinary dividends and buybacks are distributions of FCFE and are not deducted. Common-equity and noncontrolling claims can still require review.'),
 ('Debt funding','Face debt proceeds, repayments, disclosed debt cash transaction costs and identified finance-lease/equipment principal once. Equity issuance, option exercise proceeds, parent equity transfers, total financing cash flow and changes in balance-sheet debt are not substitutes.'),
 ('Expanded investment variant','Separately identifies software, licenses/IP, acquired development, financing assets, disposal receipts and capital incentives where exact cash rows can be bound. Business acquisitions, securities investment and unallocated mixed captions are excluded. This variant is a scope comparison, not automatic approval of a new platform policy.'),
 ('Missing values','Missing is never zero. Unavailable slots have no invented fiscal dates. A numerical provisional result is deliberately retained for review and must not be treated as accepted financial data.'),
 ('Comparative vintages','Original selected as-filed operands remain unchanged. Later comparative changes are saved separately; rounding-compatible differences are distinguished from larger changes. Lilly development milestones and JNJ continuing/discontinued recasts demonstrate why one revised operand must not be mixed into an otherwise old calculation.'),
 ('Stock compensation and leases','Reported CFO retains accounting cash-flow addbacks, including SBC. Noncash new leased assets are not automatically treated as current cash capex. These historical measures are not automatically comparable with an SBC-expensed/economic-investment forecast without a bridge.'),
 ('Operating-business normalization','Consolidated reported CFO can include interest/investment income and non-operating tax items. The saved cash convention is not a claim that all cash belongs only to operating assets or solely to parent common shareholders. Reconcile these items before combining the history with an EBIT-only forecast and an enterprise-to-equity bridge.'),
 ('Source precision','Exact reported source amounts are preserved, with rational arithmetic for tax ratios. Printed amounts retain their disclosed precision. Workbook calculations use ordinary floating-point arithmetic and are checked against exact saved results within USD 0.01.'),
 ('Status','Supported means defensible under this exact reported-cash convention and the checks performed. It does not certify a unique standardized FCFF/FCFE, clear issuer-specific review flags, or establish forecast assumptions/production approval.'),
 ('Reference','CFA Institute, Free Cash Flow Valuation: https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/free-cash-flow-valuation'),
]
payload=dict(metadata=meta,methodology=[dict(topic=k,explanation=v) for k,v in methodology],companies=summary,periods=periods)
(OUT/'calculations.json').write_text(json.dumps(payload,indent=2)+'\n')
(OUT/'review-data.json').write_text(json.dumps(dict(metadata=meta,methodology=payload['methodology'],companies=summary,results=results,financing=financing,flags=flags,sources=sources,cash_controls=CONTROLS['periods'],validation_checks=S['checks']),indent=2)+'\n')
for name,rows in [('financial-results',results),('company-summary',summary),('flags',flags),('financing-schedule',financing),('source-index',sources)]:
 with (OUT/(name+'.csv')).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
manifest=dict(metadata=meta,bank_source_files=OLD_D['sources'],verified_sec_bodies=S['verified_source_bodies'])
(OUT/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert len(periods)==210 and len(summary)==42 and len({p['period_key'] for p in periods})==210
assert sum(p['identity'] is not None for p in periods)==203
assert all(p['identity'] is None and p['fiscal_year'] is None for p in periods if p['record_type']=='MISSING_ANNUAL_SLOT')
assert len(S['errors'])==0
print(json.dumps(meta,indent=2));print('Rows',len(results),'Flags',len(flags),'Financing',len(financing),'Sources',len(sources))
