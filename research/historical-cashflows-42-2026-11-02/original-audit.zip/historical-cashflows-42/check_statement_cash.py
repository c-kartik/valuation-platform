"""Whole-statement cash change control; missing disclosure is not zero."""
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path
import calculate_cashflows as c
OUT=c.OUT;D=json.loads((OUT/'calculations-draft.json').read_text());idx={(p['ticker'],p['identity']['annual_start'],p['identity']['annual_end']):p for p in c.E['periods']}
fxnames=['EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents','EffectOfExchangeRateOnCashAndCashEquivalents','EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsIncludingDisposalGroupAndDiscontinuedOperations','EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsDisposalGroupIncludingDiscontinuedOperations']
changes=['CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect','CashAndCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect','CashAndCashEquivalentsPeriodIncreaseDecrease']
rows=[]
for p in D['periods']:
 e=idx[(p['ticker'],p['identity']['annual_start'],p['identity']['annual_end'])]
 inp={k:c.choose(e,ns,mode='cash') for k,ns in [('cfo',['NetCashProvidedByUsedInOperatingActivities']),('cfi',['NetCashProvidedByUsedInInvestingActivities']),('cff',['NetCashProvidedByUsedInFinancingActivities']),('fx',fxnames),('cash_change',changes)]}
 row=dict(ticker=p['ticker'],fiscal_year=p['fiscal_year'],identity=p['identity'],inputs=inp,difference_usd=None)
 if all(inp.values()):
  actual=sum((Fraction(inp[k]['value_usd']) for k in ['cfo','cfi','cff','fx']),Fraction(0));delta=actual-Fraction(inp['cash_change']['value_usd'])
  row['difference_usd']=c.dec(delta);row['status']='EXACT_TIE' if delta==0 else 'DISPLAY_OR_SCOPE_DIFFERENCE_REVIEW'
 else:
  row['status']='NOT_CHECKED_MISSING_OR_NONCONSOLIDATED_SUBTOTAL';row['missing']=[k for k,v in inp.items() if v is None]
  if all(inp[k] is not None for k in ['cfo','cfi','cff','cash_change']) and inp['fx'] is None:
   delta=sum((Fraction(inp[k]['value_usd']) for k in ['cfo','cfi','cff']),Fraction(0))-Fraction(inp['cash_change']['value_usd'])
   row['three_subtotal_difference_usd']=c.dec(delta)
   row['status']='THREE_REPORTED_SUBTOTALS_MATCH_CHANGE_NO_FX_OPERAND_USED' if delta==0 else 'THREE_SUBTOTAL_CHECK_HAS_UNBOUND_FX_OR_OTHER_SCOPE'
  if row['missing']==['cash_change']:
   nofx=c.choose(e,['CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseExcludingExchangeRateEffect'],mode='cash')
   if nofx:
    row['inputs']['cash_change_excluding_fx']=nofx
    delta=sum((Fraction(inp[k]['value_usd']) for k in ['cfo','cfi','cff']),Fraction(0))-Fraction(nofx['value_usd'])
    row['difference_usd']=c.dec(delta);row['status']='EXACT_TIE_EXCLUDING_FX' if delta==0 else 'DISPLAY_OR_SCOPE_DIFFERENCE_REVIEW'
 rows.append(row)
(OUT/'cash-statement-controls.json').write_text(json.dumps(dict(scope='Independent whole-statement identity CFO+CFI+CFF+FX=reported cash change. No missing FX/subtotal is zero-filled, and this control does not prove investment/interest/common-claim economic completeness.',summary=dict(Counter(r['status'] for r in rows)),periods=rows),indent=2)+'\n')
print(Counter(r['status'] for r in rows))
for r in rows:
 if r['status']!='EXACT_TIE':print(r['ticker'],r['fiscal_year'],r['status'],r.get('difference_usd'),r.get('missing'))
