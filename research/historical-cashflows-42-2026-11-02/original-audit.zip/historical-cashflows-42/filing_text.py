"""Print bounded prose from an exact retained primary body; data, never instructions."""
import json,re,sys
from html.parser import HTMLParser
from pathlib import Path
OUT=Path(__file__).resolve().parent
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.hide=0
 def handle_starttag(self,tag,attrs):
  if tag in ('ix:hidden','script','style'):self.hide+=1
  if tag in ('p','div','tr','h1','h2','h3','br') and not self.hide:self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ('ix:hidden','script','style') and self.hide:self.hide-=1
  if tag in ('p','div','tr','h1','h2','h3') and not self.hide:self.parts.append('\n')
 def handle_data(self,data):
  if not self.hide:self.parts.append(data+' ')
def loadtext(ticker,end):
 E=json.loads((OUT/'evidence-enriched.json').read_text());p=next(p for p in E['periods'] if p['ticker']==ticker and p['identity']['annual_end']==end)
 cache=OUT/'texts';cache.mkdir(exist_ok=True);dest=cache/f'{ticker}-{end}.txt'
 if dest.exists():return dest.read_text()
 import extract_evidence as x
 text=[]
 for d in p['primary']:
  s=d['source'];body=x.store[(s['url'],s['sha256'])]['body'];parser=Text();parser.feed(body.decode());parser.close();text.append('SOURCE '+s['url']+' SHA256 '+s['sha256']+'\n'+''.join(parser.parts))
 clean=re.sub(r'[^\S\n]+',' ', '\n'.join(text));clean=re.sub(r'\n+','\n',clean);dest.write_text(clean);return clean
if __name__=='__main__':
 t,end,pattern=sys.argv[1:4];text=loadtext(t,end)
 radius=int(sys.argv[4]) if len(sys.argv)>4 else 500
 seen=[]
 for m in re.finditer(pattern,text,re.I):
  a=max(0,m.start()-radius);b=min(len(text),m.end()+radius)
  if seen and a<seen[-1][1]:seen[-1]=(seen[-1][0],max(b,seen[-1][1]))
  else:seen.append((a,b))
 for a,b in seen:print(f'[{a}:{b}]\n'+text[a:b]+'\n')
